﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aula11._10._18
{
    public partial class FormPrincipal : Form
    {
        public string Contador, t = "Esta Matriz é Inválida", s = "Esta Matriz é Válida";
        public int QtdMAtrizes = 0, Repetidoi = 0, Repetidoj = 0;
                

        public string[,] Matriz = new string[9, 9];

        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void SubMatriz3x3()
        {
            for (int b=0; b < 9; b++)
            {
                for(int v=0; v < 9; v++)
                {
                    if (b < 3 && v < 3)
                    {
                        for (int q = 0; q < 3; q++)
                        {
                            for (int r = 0; r < 3; r++)
                            {
                                if (Matriz[q, r] == Matriz[r, q])
                                {
                                    if (q != r)
                                    {
                                        Repetidoi += 1;
                                    }
                                }
                            }
                        }
                    }
                    else
                    if (b < 6 && v < 6)
                    {
                        for (int q = 3; q < 6; q++)
                        {
                            for (int r = 3; r < 6; r++)
                            {
                                if (Matriz[q, r] == Matriz[r, q])
                                {
                                    if (q != r)
                                    {
                                        Repetidoi += 1;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int q = 6; q < 9; q++)
                        {
                            for (int r = 6; r < 9; r++)
                            {
                                if (Matriz[q, r] == Matriz[r, q])
                                {
                                    if (q != r)
                                    {
                                        Repetidoi += 1;
                                    }
                                }
                            }
                        }
                    }
                }

            }         
            
        }
        private void ConferirValoresRepetidos()
        {
            for (int c = 0; c < 9; c++)
            {
                for (int m = 0; m < 9; m++)
                {
                    
                    for (int n = 0; n < 9; n++)
                    {
                        //Teste Valor Repetido nas Linhas.
                        if (Matriz[m, c] == Matriz[m, n] || Matriz[m,n] == 0.ToString())
                        {
                            if (c != n)
                            {
                                Repetidoi += 1;
                            }
                        }
                        //Teste Valor Repetido nas Colunas.
                        if (Matriz[c, m] == Matriz[n, m] || Matriz[m, n] == 0.ToString())
                        {
                            if (c != n)
                            {
                                Repetidoj += 1;
                            }
                        }                        
                    }
                }
            }
            SubMatriz3x3();
           
            if (Repetidoi != 0 || Repetidoj != 0) //Mostrar Matriz Inválida.
            {
                richTxtBxTela.AppendText("\n\n");
                richTxtBxTela.SelectionColor = Color.DarkRed;
                richTxtBxTela.AppendText("↑  " + t);
            }
            else //Mostrar Matriz Válida.
            {
                richTxtBxTela.AppendText("\n\n");
                richTxtBxTela.SelectionColor = Color.Green;
                richTxtBxTela.AppendText("↑  " + s);
            }            
            //Zera os dados anteriores.
            Repetidoi = 0;
            Repetidoj = 0;
        }

        private void Validas()
        {
            richTxtBxTela.AppendText("\n\n");
            richTxtBxTela.SelectionColor = Color.Green;
            richTxtBxTela.AppendText(s);
            richTxtBxTela.AppendText("\n");

            for (int f=0; f < 9; f++) //Linha
            {
                for(int a=0; a < 9; a++) //Coluna
                {
                    if (a == 0)
                    {
                        richTxtBxTela.AppendText("│");
                    }
                    richTxtBxTela.AppendText(" " + Matriz[f, a].ToString() + " ");
                    if (a == 8)
                    {
                        richTxtBxTela.AppendText("│");
                    }

                    if (a == 8 && f == 8) //Quando completar o lançamento na Matriz[9,9].
                    {
                        richTxtBxTela.AppendText("\n" + "                                            ⁹×⁹");                        
                    }
                }
                richTxtBxTela.AppendText("\n");
            }
        }

        private void Invalidas()
        {
            richTxtBxTela.AppendText("\n\n");
            richTxtBxTela.SelectionColor = Color.Red;
            richTxtBxTela.AppendText(t);
            richTxtBxTela.AppendText("\n");

            for (int f = 0; f < 9; f++) //Linha
            {
                for (int a = 0; a < 9; a++) //Coluna
                {
                    if (a == 0)
                    {
                        richTxtBxTela.AppendText("│");
                    }
                    richTxtBxTela.AppendText(" " + Matriz[f, a].ToString() + " ");
                    if (a == 8)
                    {
                        richTxtBxTela.AppendText("│");
                    }
                    if (a == 8 && f == 8) //Quando completar o lançamento na Matriz[9,9].
                    {
                        richTxtBxTela.AppendText("\n" + "                                            ⁹×⁹");
                    }
                }
                richTxtBxTela.AppendText("\n");
            }
        }

        private void bttnVerificar_Click(object sender, EventArgs e)
        {
            StreamReader Leitor = new StreamReader(txtBxCaminho.Text);
            Contador = Leitor.ReadLine();

            richTxtBxTela.AppendText("\n");
            if (char.IsNumber(Contador, 0)) //Verificar se são números.
            {                               
                while (Contador != null)
                {
                    //Contador em Array.
                    Contador.ToCharArray().ToString();
                    
                    for (int i = 0; i < 9; i++) //Linha
                    {
                        //Verificar se ainda tem valores.
                        if (Contador == null)
                        {
                            break;
                        }
                        for (int j = 0; j < 9; j++) //Coluna
                        {
                            Matriz[i, j] = Contador[j].ToString(); //Lançar Valores.
                            if (j == 0)
                            {
                                richTxtBxTela.AppendText("│");
                            }
                            richTxtBxTela.AppendText(" " + Matriz[i, j].ToString() + " "); //Mostrar.
                            if (j == 8)
                            {
                                richTxtBxTela.AppendText("│");
                            }
                            if (i == 8 && j == 8) //Quando completar o lançamento na Matriz[9,9].
                            {
                                richTxtBxTela.AppendText("\n" + "                                            ⁹×⁹");
                                ConferirValoresRepetidos();
                            }
                        }
                        //Pega o próximo valor do Txt.
                        Contador = Leitor.ReadLine();
                        richTxtBxTela.AppendText("\n");
                        //Contador de Matrizes.
                        if (i == 8)
                        {
                            richTxtBxTela.AppendText("\n");
                            QtdMAtrizes++;
                        }
                    }
                    
                }
                //Mostrar Qtd matriz na tela.
                richTxtBxTela.AppendText("\n" + "\n" + "\n" + "→   Matrizez[9,9] = " + QtdMAtrizes.ToString());
            }
            else
            {
                MessageBox.Show("Apenas números OU Excesso de elementos");
                return;
            }
            if (comboBox1.SelectedIndex == 0)
            {
                richTxtBxTela.Clear();
                Validas();
            }
            else
            if (comboBox1.SelectedIndex == 1)
            {
                richTxtBxTela.Clear();
                Invalidas();
            }

        }

        private void bttnBuscar_Click(object sender, EventArgs e)
        {            
            openFileDialog1.ShowDialog();
            txtBxCaminho.Text = openFileDialog1.FileName;

            MessageBox.Show("Agora clique em Verificar.", "Atenção!", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
        }

        private void bttnSalvar_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                richTxtBxTela.SaveFile(saveFileDialog1.FileName);
            }
        }
    }
}

