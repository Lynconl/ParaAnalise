﻿namespace aula11._10._18
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttnBuscar = new System.Windows.Forms.Button();
            this.txtBxCaminho = new System.Windows.Forms.TextBox();
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            this.bttnSalvar = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.bttnVerificar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bttnBuscar
            // 
            this.bttnBuscar.BackColor = System.Drawing.SystemColors.Control;
            this.bttnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttnBuscar.Location = new System.Drawing.Point(426, 10);
            this.bttnBuscar.Name = "bttnBuscar";
            this.bttnBuscar.Size = new System.Drawing.Size(112, 41);
            this.bttnBuscar.TabIndex = 0;
            this.bttnBuscar.Text = "Buscar";
            this.bttnBuscar.UseVisualStyleBackColor = false;
            this.bttnBuscar.Click += new System.EventHandler(this.bttnBuscar_Click);
            // 
            // txtBxCaminho
            // 
            this.txtBxCaminho.Location = new System.Drawing.Point(12, 10);
            this.txtBxCaminho.Multiline = true;
            this.txtBxCaminho.Name = "txtBxCaminho";
            this.txtBxCaminho.Size = new System.Drawing.Size(395, 41);
            this.txtBxCaminho.TabIndex = 1;
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.Location = new System.Drawing.Point(12, 57);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.richTxtBxTela.Size = new System.Drawing.Size(1084, 333);
            this.richTxtBxTela.TabIndex = 2;
            this.richTxtBxTela.Text = "";
            // 
            // bttnSalvar
            // 
            this.bttnSalvar.BackColor = System.Drawing.SystemColors.Control;
            this.bttnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttnSalvar.Location = new System.Drawing.Point(722, 10);
            this.bttnSalvar.Name = "bttnSalvar";
            this.bttnSalvar.Size = new System.Drawing.Size(113, 41);
            this.bttnSalvar.TabIndex = 3;
            this.bttnSalvar.Text = "Salvar";
            this.bttnSalvar.UseVisualStyleBackColor = false;
            this.bttnSalvar.Click += new System.EventHandler(this.bttnSalvar_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // comboBox1
            // 
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Apenas Válidas",
            "Apenas Inválidas"});
            this.comboBox1.Location = new System.Drawing.Point(861, 18);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboBox1.Size = new System.Drawing.Size(235, 33);
            this.comboBox1.TabIndex = 4;
            this.comboBox1.Text = "Selecione o Filtro";
            // 
            // bttnVerificar
            // 
            this.bttnVerificar.BackColor = System.Drawing.SystemColors.Control;
            this.bttnVerificar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttnVerificar.Location = new System.Drawing.Point(558, 10);
            this.bttnVerificar.Name = "bttnVerificar";
            this.bttnVerificar.Size = new System.Drawing.Size(144, 41);
            this.bttnVerificar.TabIndex = 5;
            this.bttnVerificar.Text = "Verificar";
            this.bttnVerificar.UseVisualStyleBackColor = false;
            this.bttnVerificar.Click += new System.EventHandler(this.bttnVerificar_Click);
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1108, 402);
            this.Controls.Add(this.bttnVerificar);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.bttnSalvar);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.txtBxCaminho);
            this.Controls.Add(this.bttnBuscar);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "FormPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tela Inicial";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttnBuscar;
        private System.Windows.Forms.TextBox txtBxCaminho;
        private System.Windows.Forms.RichTextBox richTxtBxTela;
        private System.Windows.Forms.Button bttnSalvar;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button bttnVerificar;
    }
}

