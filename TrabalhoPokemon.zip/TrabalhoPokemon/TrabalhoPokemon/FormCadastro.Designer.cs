﻿namespace TrabalhoPokemon
{
    partial class FormCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblLoginC = new System.Windows.Forms.Label();
            this.lblSenhaC = new System.Windows.Forms.Label();
            this.txtBoxNome = new System.Windows.Forms.TextBox();
            this.txtBoxUsuarioC = new System.Windows.Forms.TextBox();
            this.txtBoxSenhaC = new System.Windows.Forms.TextBox();
            this.bttnFinalizar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(12, 25);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(67, 24);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome:";
            // 
            // lblLoginC
            // 
            this.lblLoginC.AutoSize = true;
            this.lblLoginC.Location = new System.Drawing.Point(9, 106);
            this.lblLoginC.Name = "lblLoginC";
            this.lblLoginC.Size = new System.Drawing.Size(62, 24);
            this.lblLoginC.TabIndex = 1;
            this.lblLoginC.Text = "Login:";
            // 
            // lblSenhaC
            // 
            this.lblSenhaC.AutoSize = true;
            this.lblSenhaC.Location = new System.Drawing.Point(9, 192);
            this.lblSenhaC.Name = "lblSenhaC";
            this.lblSenhaC.Size = new System.Drawing.Size(70, 24);
            this.lblSenhaC.TabIndex = 2;
            this.lblSenhaC.Text = "Senha:";
            // 
            // txtBoxNome
            // 
            this.txtBoxNome.Location = new System.Drawing.Point(104, 21);
            this.txtBoxNome.Name = "txtBoxNome";
            this.txtBoxNome.Size = new System.Drawing.Size(191, 28);
            this.txtBoxNome.TabIndex = 3;
            // 
            // txtBoxUsuarioC
            // 
            this.txtBoxUsuarioC.Location = new System.Drawing.Point(104, 102);
            this.txtBoxUsuarioC.Name = "txtBoxUsuarioC";
            this.txtBoxUsuarioC.Size = new System.Drawing.Size(191, 28);
            this.txtBoxUsuarioC.TabIndex = 4;
            // 
            // txtBoxSenhaC
            // 
            this.txtBoxSenhaC.Location = new System.Drawing.Point(104, 188);
            this.txtBoxSenhaC.Name = "txtBoxSenhaC";
            this.txtBoxSenhaC.PasswordChar = '*';
            this.txtBoxSenhaC.Size = new System.Drawing.Size(191, 28);
            this.txtBoxSenhaC.TabIndex = 5;
            // 
            // bttnFinalizar
            // 
            this.bttnFinalizar.BackColor = System.Drawing.SystemColors.Info;
            this.bttnFinalizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttnFinalizar.Location = new System.Drawing.Point(104, 273);
            this.bttnFinalizar.Name = "bttnFinalizar";
            this.bttnFinalizar.Size = new System.Drawing.Size(136, 35);
            this.bttnFinalizar.TabIndex = 6;
            this.bttnFinalizar.Text = "Finalizar";
            this.bttnFinalizar.UseVisualStyleBackColor = false;
            this.bttnFinalizar.Click += new System.EventHandler(this.bttnFinalizar_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(1, 236);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(334, 13);
            this.button1.TabIndex = 7;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // FormCadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(333, 320);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bttnFinalizar);
            this.Controls.Add(this.txtBoxSenhaC);
            this.Controls.Add(this.txtBoxUsuarioC);
            this.Controls.Add(this.txtBoxNome);
            this.Controls.Add(this.lblSenhaC);
            this.Controls.Add(this.lblLoginC);
            this.Controls.Add(this.lblNome);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FormCadastro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro Treinador";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblLoginC;
        private System.Windows.Forms.Label lblSenhaC;
        private System.Windows.Forms.TextBox txtBoxNome;
        private System.Windows.Forms.TextBox txtBoxUsuarioC;
        private System.Windows.Forms.TextBox txtBoxSenhaC;
        private System.Windows.Forms.Button bttnFinalizar;
        private System.Windows.Forms.Button button1;
    }
}