﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TrabalhoPokemon
{
    public partial class CadastroPokemon : Form
    {        
        public CadastroPokemon()
        {
            InitializeComponent();
            
            Path.GetDirectoryName(Application.ExecutablePath); //Pega o local do arquivo.
            if (File.Exists(@"..\Save\Pokemons.txt")) //Confere se já existe.
            {
                
            }
            else
            {
                StreamWriter X = new StreamWriter(@"..\Save\Pokemons.txt");
                FileInfo Arquivo = new FileInfo(@"..\Save\Pokemons.txt");
            }
                        
        }       

        private void bttnFinalizar_Click(object sender, EventArgs e)
        {
            List<Pokemons> CadPokemons = new List<Pokemons>();
            Pokemons Inserir = new Pokemons();
            
            StreamWriter X = File.AppendText(@"..\Save\Pokemons.txt");
            Random efeitopoke = new Random();
            
            Inserir.Id1 = 1;
            Inserir.Nome = txtBoxNome.Text;
            Inserir.Evolucao = txtBoxEvolucao.Text;
            Inserir.Altura = Convert.ToInt16(numericUDAltura.Value);
            Inserir.Peso = Convert.ToInt16(numericUDPeso.Value);
            Inserir.Efeito = efeitopoke.Next(1, 5);
            Inserir.Forca = Convert.ToInt16(Math.Sqrt((Inserir.Altura * Inserir.Peso) + Inserir.Efeito));

            CadPokemons.Add(Inserir);

            X.WriteLine(Inserir.Id1);
            X.Write(Inserir.Nome + Environment.NewLine);
            X.Write(Inserir.Evolucao + Environment.NewLine);
            X.Write(Inserir.Altura + Environment.NewLine);
            X.Write(Inserir.Peso + Environment.NewLine);
            X.WriteLine(Inserir.Forca);
            X.WriteLine(Inserir.Efeito);

            X.Close();
            this.Close();
        }

        private void bttnImagem_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            openFileDialog1.Title = "Selecione a imagem";
            openFileDialog1.Filter = "JPEG|*.JPG|PNG|*.png";
            openFileDialog1.ShowDialog();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            pictureBoxImagem.Image = Image.FromFile(openFileDialog1.FileName);
        }

        private void bttnFiltrar_Click(object sender, EventArgs e)
        {
            if(comboBoxListar.SelectedIndex == 0)
            {

            }
            if(comboBoxListar.SelectedIndex == 1)
            {

            }
            if(comboBoxListar.SelectedIndex == 2)
            {

            }
            if(comboBoxListar.SelectedIndex == 3)
            {

            }
            else
            {
                //List<string> Linhas = new List<string>(File.ReadLines(@"..\Save\Pokemons.txt"));

                //dataGridViewTelaPoke.Rows[0].HeaderCell.Value = Pokemons;
                //dataGridViewTelaPoke.Rows[0].Cells[1].Value = Pokemons;
            }
        }
    }
}
