﻿namespace TrabalhoPokemon
{
    partial class FormTelaInicial
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTelaInicial));
            this.lblLogin = new System.Windows.Forms.Label();
            this.txtBoxUsuario = new System.Windows.Forms.TextBox();
            this.bttnCadastro = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bttnEntrar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoxSenha = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogin.Location = new System.Drawing.Point(12, 169);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(70, 25);
            this.lblLogin.TabIndex = 0;
            this.lblLogin.Text = "Login:";
            // 
            // txtBoxUsuario
            // 
            this.txtBoxUsuario.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxUsuario.Location = new System.Drawing.Point(101, 160);
            this.txtBoxUsuario.Name = "txtBoxUsuario";
            this.txtBoxUsuario.Size = new System.Drawing.Size(154, 34);
            this.txtBoxUsuario.TabIndex = 1;
            this.txtBoxUsuario.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBoxUsuario_KeyDown);
            // 
            // bttnCadastro
            // 
            this.bttnCadastro.BackColor = System.Drawing.SystemColors.Info;
            this.bttnCadastro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttnCadastro.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnCadastro.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bttnCadastro.Location = new System.Drawing.Point(270, 215);
            this.bttnCadastro.Name = "bttnCadastro";
            this.bttnCadastro.Size = new System.Drawing.Size(125, 32);
            this.bttnCadastro.TabIndex = 4;
            this.bttnCadastro.Text = "Cadastrar";
            this.bttnCadastro.UseVisualStyleBackColor = false;
            this.bttnCadastro.Click += new System.EventHandler(this.bttnCadastro_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(383, 122);
            this.panel1.TabIndex = 3;
            // 
            // bttnEntrar
            // 
            this.bttnEntrar.BackColor = System.Drawing.SystemColors.Info;
            this.bttnEntrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttnEntrar.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnEntrar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bttnEntrar.Location = new System.Drawing.Point(272, 160);
            this.bttnEntrar.Name = "bttnEntrar";
            this.bttnEntrar.Size = new System.Drawing.Size(123, 34);
            this.bttnEntrar.TabIndex = 3;
            this.bttnEntrar.Text = "Entrar";
            this.bttnEntrar.UseVisualStyleBackColor = false;
            this.bttnEntrar.Click += new System.EventHandler(this.bttnEntrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 222);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Senha:";
            // 
            // txtBoxSenha
            // 
            this.txtBoxSenha.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxSenha.Location = new System.Drawing.Point(101, 213);
            this.txtBoxSenha.Name = "txtBoxSenha";
            this.txtBoxSenha.PasswordChar = '*';
            this.txtBoxSenha.Size = new System.Drawing.Size(154, 34);
            this.txtBoxSenha.TabIndex = 2;
            this.txtBoxSenha.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBoxSenha_KeyDown);
            // 
            // FormTelaInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(407, 270);
            this.Controls.Add(this.txtBoxSenha);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bttnEntrar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.bttnCadastro);
            this.Controls.Add(this.txtBoxUsuario);
            this.Controls.Add(this.lblLogin);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "FormTelaInicial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login/Cadastro";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.TextBox txtBoxUsuario;
        private System.Windows.Forms.Button bttnCadastro;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bttnEntrar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxSenha;
    }
}

