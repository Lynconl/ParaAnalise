﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;

namespace TrabalhoPokemon
{
    public partial class FormCadastro : Form
    {
        public FormCadastro()
        {
            InitializeComponent();
            
        }
        List<Treinador> Treinadores = new List<Treinador>();

        private void bttnFinalizar_Click(object sender, EventArgs e)
        {
            if (!Regex.IsMatch(txtBoxNome.Text, @"^[a-zA-Z]+$"))
            {
                MessageBox.Show("Nome deve conter apenas Letras", "Aviso", MessageBoxButtons.OK);
            }
            else
            {
                Treinador t1 = new Treinador();                
                StreamWriter X = File.AppendText(@"..\Save\Dados.txt");
                t1.Nome = txtBoxNome.Text;
                t1.Login = txtBoxUsuarioC.Text;
                t1.Senha = txtBoxSenhaC.Text;
                Treinadores.Add(t1);
                X.WriteLine(t1.Nome);
                X.WriteLine(t1.Login);
                X.WriteLine(t1.Senha);
                X.Close();
                this.Close();
            }           
        }
    }
}
