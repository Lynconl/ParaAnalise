﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TrabalhoPokemon
{
    public partial class FormTelaInicial : Form
    {
        public FormTelaInicial()
        {
            InitializeComponent();
            Save();
        }
        private void Save()
        {        
            if (File.Exists("C:\\Users\\Dell\\OneDrive - Complexo de Ensino Superior do Brasil LTDA\\Bonilha\\TrabalhoPokemon\\TrabalhoPokemon\\Save"))
            {

            }
            else
            {
                StreamWriter writer = new StreamWriter("C:\\Users\\Dell\\OneDrive - Complexo de Ensino Superior do Brasil LTDA\\Bonilha\\TrabalhoPokemon\\TrabalhoPokemon\\Save");
                //FileInfo Arquivo = new FileInfo("..\\Save\\Dados.txt");
            }
        }

        private void bttnCadastro_Click(object sender, EventArgs e)
        {
            FormCadastro Abrir = new FormCadastro();
            Abrir.ShowDialog();
        }

        private void bttnEntrar_Click(object sender, EventArgs e)
        {
            FormJogo Abrir = new FormJogo();
            Abrir.ShowDialog();

            this.Close();
        }
    }
}
