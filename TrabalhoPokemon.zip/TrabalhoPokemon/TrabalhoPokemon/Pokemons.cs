﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabalhoPokemon
{
    class Pokemons
    {
        private int Id;
        private string nome;
        private string evolucao;
        private int altura;
        private int peso;
        private int forca;
        private int efeito;
        

        public string Evolucao { get => evolucao; set => evolucao = value; }
        public string Nome { get => nome; set => nome = value; }
        public int Altura { get => altura; set => altura = value; }
        public int Peso { get => peso; set => peso = value; }
        public int Forca { get => forca; set => forca = value; }
        public int Efeito { get => efeito; set => efeito = value; }
        public int Id1 { get => Id; set => Id = value; }

        public Pokemons()
        {

        }
    }
}
