﻿namespace TrabalhoPokemon
{
    partial class CadastroPokemon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastroPokemon));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBoxNome = new System.Windows.Forms.TextBox();
            this.txtBoxEvolucao = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.bttnImagem = new System.Windows.Forms.Button();
            this.numericUDAltura = new System.Windows.Forms.NumericUpDown();
            this.numericUDPeso = new System.Windows.Forms.NumericUpDown();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bttnFinalizar = new System.Windows.Forms.Button();
            this.pictureBoxImagem = new System.Windows.Forms.PictureBox();
            this.comboBoxListar = new System.Windows.Forms.ComboBox();
            this.bttnFiltrar = new System.Windows.Forms.Button();
            this.lblID = new System.Windows.Forms.Label();
            this.dataGridViewTelaPoke = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDAltura)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDPeso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxImagem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTelaPoke)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 24);
            this.label1.TabIndex = 10;
            this.label1.Text = "Identificador:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 24);
            this.label2.TabIndex = 11;
            this.label2.Text = "Nome:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 24);
            this.label3.TabIndex = 12;
            this.label3.Text = "Imagem:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 229);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 24);
            this.label4.TabIndex = 13;
            this.label4.Text = "Evolução:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 294);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 24);
            this.label5.TabIndex = 15;
            this.label5.Text = "Altura(cm):";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 360);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 24);
            this.label6.TabIndex = 16;
            this.label6.Text = "Peso(Kgs):";
            // 
            // txtBoxNome
            // 
            this.txtBoxNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxNome.Location = new System.Drawing.Point(154, 87);
            this.txtBoxNome.Name = "txtBoxNome";
            this.txtBoxNome.Size = new System.Drawing.Size(154, 28);
            this.txtBoxNome.TabIndex = 2;
            // 
            // txtBoxEvolucao
            // 
            this.txtBoxEvolucao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxEvolucao.Location = new System.Drawing.Point(154, 225);
            this.txtBoxEvolucao.Name = "txtBoxEvolucao";
            this.txtBoxEvolucao.Size = new System.Drawing.Size(154, 28);
            this.txtBoxEvolucao.TabIndex = 4;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // bttnImagem
            // 
            this.bttnImagem.BackColor = System.Drawing.SystemColors.Info;
            this.bttnImagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnImagem.Location = new System.Drawing.Point(154, 153);
            this.bttnImagem.Name = "bttnImagem";
            this.bttnImagem.Size = new System.Drawing.Size(154, 37);
            this.bttnImagem.TabIndex = 3;
            this.bttnImagem.Text = "Inserir Imagem";
            this.bttnImagem.UseVisualStyleBackColor = false;
            this.bttnImagem.Click += new System.EventHandler(this.bttnImagem_Click);
            // 
            // numericUDAltura
            // 
            this.numericUDAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUDAltura.Location = new System.Drawing.Point(154, 294);
            this.numericUDAltura.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.numericUDAltura.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUDAltura.Name = "numericUDAltura";
            this.numericUDAltura.Size = new System.Drawing.Size(154, 28);
            this.numericUDAltura.TabIndex = 5;
            this.numericUDAltura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDAltura.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUDPeso
            // 
            this.numericUDPeso.DecimalPlaces = 1;
            this.numericUDPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUDPeso.Location = new System.Drawing.Point(154, 356);
            this.numericUDPeso.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.numericUDPeso.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUDPeso.Name = "numericUDPeso";
            this.numericUDPeso.Size = new System.Drawing.Size(154, 28);
            this.numericUDPeso.TabIndex = 17;
            this.numericUDPeso.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDPeso.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel2.Location = new System.Drawing.Point(351, 19);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(270, 96);
            this.panel2.TabIndex = 11;
            // 
            // bttnFinalizar
            // 
            this.bttnFinalizar.BackColor = System.Drawing.SystemColors.Info;
            this.bttnFinalizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnFinalizar.Location = new System.Drawing.Point(401, 347);
            this.bttnFinalizar.Name = "bttnFinalizar";
            this.bttnFinalizar.Size = new System.Drawing.Size(154, 37);
            this.bttnFinalizar.TabIndex = 18;
            this.bttnFinalizar.Text = "Finalizar";
            this.bttnFinalizar.UseVisualStyleBackColor = false;
            this.bttnFinalizar.Click += new System.EventHandler(this.bttnFinalizar_Click);
            // 
            // pictureBoxImagem
            // 
            this.pictureBoxImagem.Location = new System.Drawing.Point(351, 153);
            this.pictureBoxImagem.Name = "pictureBoxImagem";
            this.pictureBoxImagem.Size = new System.Drawing.Size(270, 169);
            this.pictureBoxImagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxImagem.TabIndex = 19;
            this.pictureBoxImagem.TabStop = false;
            // 
            // comboBoxListar
            // 
            this.comboBoxListar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxListar.FormattingEnabled = true;
            this.comboBoxListar.Items.AddRange(new object[] {
            "Listar por Altura: Menor para Maior.",
            "Listar por Peso: Menor para Maior.",
            "Listar por Nome: Ordem alfabética.",
            "Listar por Força: Menor para Maior."});
            this.comboBoxListar.Location = new System.Drawing.Point(652, 23);
            this.comboBoxListar.Name = "comboBoxListar";
            this.comboBoxListar.Size = new System.Drawing.Size(289, 30);
            this.comboBoxListar.TabIndex = 21;
            this.comboBoxListar.Text = "Listar Dados";
            // 
            // bttnFiltrar
            // 
            this.bttnFiltrar.BackColor = System.Drawing.SystemColors.Info;
            this.bttnFiltrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnFiltrar.Location = new System.Drawing.Point(978, 15);
            this.bttnFiltrar.Name = "bttnFiltrar";
            this.bttnFiltrar.Size = new System.Drawing.Size(131, 37);
            this.bttnFiltrar.TabIndex = 22;
            this.bttnFiltrar.Text = "Filtrar";
            this.bttnFiltrar.UseVisualStyleBackColor = false;
            this.bttnFiltrar.Click += new System.EventHandler(this.bttnFiltrar_Click);
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Microsoft JhengHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.Location = new System.Drawing.Point(168, 22);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(0, 24);
            this.lblID.TabIndex = 23;
            // 
            // dataGridViewTelaPoke
            // 
            this.dataGridViewTelaPoke.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dataGridViewTelaPoke.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTelaPoke.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.dataGridViewTelaPoke.Location = new System.Drawing.Point(652, 103);
            this.dataGridViewTelaPoke.Name = "dataGridViewTelaPoke";
            this.dataGridViewTelaPoke.RowTemplate.Height = 24;
            this.dataGridViewTelaPoke.Size = new System.Drawing.Size(457, 289);
            this.dataGridViewTelaPoke.TabIndex = 24;
            // 
            // CadastroPokemon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(1121, 404);
            this.Controls.Add(this.dataGridViewTelaPoke);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.bttnFiltrar);
            this.Controls.Add(this.comboBoxListar);
            this.Controls.Add(this.pictureBoxImagem);
            this.Controls.Add(this.bttnFinalizar);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.numericUDPeso);
            this.Controls.Add(this.numericUDAltura);
            this.Controls.Add(this.bttnImagem);
            this.Controls.Add(this.txtBoxEvolucao);
            this.Controls.Add(this.txtBoxNome);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "CadastroPokemon";
            this.Text = "CadastroPokemon";
            ((System.ComponentModel.ISupportInitialize)(this.numericUDAltura)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDPeso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxImagem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTelaPoke)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtBoxNome;
        private System.Windows.Forms.TextBox txtBoxEvolucao;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button bttnImagem;
        private System.Windows.Forms.NumericUpDown numericUDAltura;
        private System.Windows.Forms.NumericUpDown numericUDPeso;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button bttnFinalizar;
        private System.Windows.Forms.PictureBox pictureBoxImagem;
        private System.Windows.Forms.ComboBox comboBoxListar;
        private System.Windows.Forms.Button bttnFiltrar;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.DataGridView dataGridViewTelaPoke;
    }
}