﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TrabalhoPokemon
{
    public partial class FormTelaInicial : Form
    {
        bool Enter;
        public FormTelaInicial()
        {
            InitializeComponent();
            Save();
        }
        
        private void Save()
        {
            Path.GetDirectoryName(Application.ExecutablePath); //Pega o local do arquivo.
            if (File.Exists(@"..\Save\Dados.txt")) //Confere se já existe.
            {
                
            }
            else
            {
                StreamWriter X = new StreamWriter(@"..\Save\Dados.txt");
                X.Close();
            }
        }

        private void bttnCadastro_Click(object sender, EventArgs e)
        {
            FormCadastro Abrir = new FormCadastro(); //Abrir a Tela Cadastro.
            Abrir.ShowDialog();
        }

        private void bttnEntrar_Click(object sender, EventArgs e)
        {
            List<string> Linhas = new List<string>(File.ReadLines(@"..\Save\Dados.txt")); //Cria a Lista com os Dados.txt
            
            for(int i=1; i <= Linhas.Count; i = i+3)
            {
                if (txtBoxUsuario.Text == Linhas[i] && txtBoxSenha.Text == Linhas[i+1]) //Confere Login & Senha.
                {
                    MessageBox.Show("Seja Bem-Vindo!", "Pokémon Game", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    FormJogo Abrir = new FormJogo();
                    Abrir.ShowDialog(); Close();
                    
                    
                }
            }
            {
                MessageBox.Show("Login ou senha incorretos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBoxUsuario.Clear();
                txtBoxSenha.Clear();
            }

        }

        private void txtBoxSenha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Enter = true;
            }
            else
            {
                Enter = false;
            }
            if (Enter == true)
            {
                bttnEntrar_Click(sender, e);
            }
        }

        private void txtBoxUsuario_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Enter = true;
            }
            else
            {
                Enter = false;
            }
            if (Enter == true)
            {
                bttnEntrar_Click(sender, e);
            }
        }
    }
}
