﻿namespace Buscar_Informações_em_Txt
{
    partial class FormInicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.numericUDInicio = new System.Windows.Forms.NumericUpDown();
            this.numericUDTamanho = new System.Windows.Forms.NumericUpDown();
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.numericUDIrde = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDInicio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDTamanho)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDIrde)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.Font = new System.Drawing.Font("Constantia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(650, 55);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(77, 26);
            this.button1.TabIndex = 3;
            this.button1.Text = "Abrir";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox1.Location = new System.Drawing.Point(175, 55);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(450, 26);
            this.textBox1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Caminho do arquivo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = "Coluna Início:";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(485, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "Tamanho:";
            // 
            // numericUDInicio
            // 
            this.numericUDInicio.Location = new System.Drawing.Point(127, 12);
            this.numericUDInicio.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUDInicio.Name = "numericUDInicio";
            this.numericUDInicio.Size = new System.Drawing.Size(152, 27);
            this.numericUDInicio.TabIndex = 0;
            this.numericUDInicio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // numericUDTamanho
            // 
            this.numericUDTamanho.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.numericUDTamanho.Location = new System.Drawing.Point(575, 12);
            this.numericUDTamanho.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUDTamanho.Name = "numericUDTamanho";
            this.numericUDTamanho.Size = new System.Drawing.Size(152, 27);
            this.numericUDTamanho.TabIndex = 2;
            this.numericUDTamanho.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTxtBxTela.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTxtBxTela.Location = new System.Drawing.Point(15, 102);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.Size = new System.Drawing.Size(712, 213);
            this.richTxtBxTela.TabIndex = 5;
            this.richTxtBxTela.Text = "";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(306, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "Ir de:";
            // 
            // numericUDIrde
            // 
            this.numericUDIrde.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.numericUDIrde.Location = new System.Drawing.Point(359, 12);
            this.numericUDIrde.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUDIrde.Name = "numericUDIrde";
            this.numericUDIrde.Size = new System.Drawing.Size(93, 27);
            this.numericUDIrde.TabIndex = 1;
            this.numericUDIrde.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FormInicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 327);
            this.Controls.Add(this.numericUDIrde);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.numericUDTamanho);
            this.Controls.Add(this.numericUDInicio);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Constantia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FormInicio";
            this.Text = ":D";
            ((System.ComponentModel.ISupportInitialize)(this.numericUDInicio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDTamanho)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDIrde)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numericUDInicio;
        private System.Windows.Forms.NumericUpDown numericUDTamanho;
        private System.Windows.Forms.RichTextBox richTxtBxTela;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numericUDIrde;
    }
}

