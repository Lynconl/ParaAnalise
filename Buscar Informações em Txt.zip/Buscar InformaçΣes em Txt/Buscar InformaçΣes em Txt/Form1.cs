﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Buscar_Informações_em_Txt
{
    public partial class FormInicio : Form
    {
        List<string> Repetidos = new List<string>();
        public FormInicio()
        {
            InitializeComponent();
        }

        private string arquivo;
        private string mensagem;
        
        private void MetodoParaLerLinhaArquivo()
        {
            List<string> mensagemLinha = new List<string>();
            List<string> mensagemLinha2 = new List<string>();
            int inicio, fim, Irde;
            string Amostra;

            inicio = Convert.ToInt32(numericUDInicio.Value);
            fim = Convert.ToInt32(numericUDTamanho.Value);
            Irde = Convert.ToInt32(numericUDIrde.Value);

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Title = "Escolha o arquivo .txt";
                openFileDialog.InitialDirectory = @"C:\Users\Lynconl Assunção\Desktop"; //Se ja quiser em abrir em um diretorio especifico
                openFileDialog.Filter = "All files (*.txt*)|*.txt*|All files (*.txt*)|*.txt*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                    arquivo = openFileDialog.FileName;
                
            }
            if (String.IsNullOrEmpty(arquivo))
            {
                MessageBox.Show("Arquivo Invalido", "Salvar Como", MessageBoxButtons.OK);
            }
            else
            {
                textBox1.Text = arquivo;
                using (StreamReader texto = new StreamReader(arquivo))
                {
                    while ((mensagem = texto.ReadLine()) != null)
                    {
                        mensagemLinha.Add(mensagem);
                        mensagemLinha2.Add(mensagem);
                    }
                }
                int registro = mensagemLinha.Count; //total de linhas do arquivo.
                MessageBox.Show("Arquivo com: " + registro.ToString() + " Linhas.", "Aviso",
                    MessageBoxButtons.OK);

                for (int i = 1; i < mensagemLinha.Count -1; i += Irde)
                {
                    mensagemLinha[i] = mensagemLinha[i].Substring(inicio, fim);
                    richTxtBxTela.AppendText(mensagemLinha[i] + "   -- Linha: " + (i+1) + Environment.NewLine);

                    for (int j = 1; j < mensagemLinha2.Count -1; j += Irde)
                    {
                        Amostra = mensagemLinha2[j];
                        Amostra = Amostra.Substring(inicio, fim);
                        if (i != j && mensagemLinha[i] == Amostra)
                        {                           
                            Repetidos.Add(mensagemLinha[i]+"   -- Linha: " + (i + 1));                            
                        }
                    }
                }

                MessageBox.Show("Repetidos pintados em vermelho!", "Aviso");
                foreach(string t in Repetidos)
                {
                    string s = t.ToString();
                    int h = richTxtBxTela.Find(s, RichTextBoxFinds.None);
                    richTxtBxTela.Select(h, s.Length);
                    richTxtBxTela.SelectionColor = Color.Red;
                }

            }
            
        }        

        private void button1_Click(object sender, EventArgs e)
        {
            richTxtBxTela.Clear();
            MetodoParaLerLinhaArquivo();           
        }
    }
}
