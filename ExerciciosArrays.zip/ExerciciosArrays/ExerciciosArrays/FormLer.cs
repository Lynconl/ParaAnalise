﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExerciciosArrays
{
    public partial class FormLer : Form
    {
        int Item = 0;
        public FormLer()
        {
            InitializeComponent();
        }

        private void bttnValor_Click(object sender, EventArgs e)
        {
            int Valor;
            textBox1.Focus();

            if (int.TryParse(textBox1.Text, out Valor))
            {
                if (Item <= FormPrincipal.Dados1.Length - 1)
                {
                    FormPrincipal.Dados1[Item] = Valor;
                    Item++;
                }
                else
                {
                    MessageBox.Show("Tamanho do Array Excedido!");
                }
            }
            else
            {
                MessageBox.Show("Erro, Informe somente valores inteiros!");
            }
            dataGridView1.Rows.Clear();
            foreach(int n in FormPrincipal.Dados1)
            {
                dataGridView1.Rows.Add(n.ToString());
            }
        }
    }   
}
