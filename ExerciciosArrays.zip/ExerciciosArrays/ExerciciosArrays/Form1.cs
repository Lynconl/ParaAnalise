﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExerciciosArrays
{
    public partial class FormPrincipal : Form
    {
        public static int[] Dados1;
        int[] Dados2;
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dados1 = new int[(int)numericUDArray.Value];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormLer Ler = new FormLer();
            Ler.ShowDialog();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            richTxtBxTela.Clear();
            richTxtBxTela.AppendText("Exercício 01!" + Environment.NewLine + Environment.NewLine);

            for(int i=0; i<= Dados1.Length - 1; i++)
            {
                richTxtBxTela.AppendText("Posição [" + i.ToString() + "]: " + Dados1[i].ToString() + Environment.NewLine);
            }
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            richTxtBxTela.Clear();
            richTxtBxTela.AppendText("Exercício 02!" + Environment.NewLine + Environment.NewLine);

            for(int i = Dados1.Length - 1; i >= 0; i--)
            {
                richTxtBxTela.AppendText("Posição [" + i.ToString() + "]: " + Dados1[i].ToString() + Environment.NewLine);
            }
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            richTxtBxTela.Clear();
            richTxtBxTela.AppendText("Exercício 03!" + Environment.NewLine + Environment.NewLine);
            int soma = 0;

            for(int i = Dados1.Length - 1; i >= 0; i--)
            {
                soma += Dados1[i];
            }
            richTxtBxTela.AppendText("A soma dos Dados é: " + soma.ToString() + Environment.NewLine);
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            Dados2 = Dados1;
            richTxtBxTela.Clear();
            richTxtBxTela.AppendText("Exercício 04!" + Environment.NewLine + Environment.NewLine);            

            for (int i = Dados2.Length - 1; i >= 0; i--)
            {
                richTxtBxTela.AppendText("Posição [" + i.ToString() + "]: " + Dados2[i].ToString() + Environment.NewLine);
            }
        }
    }
}
