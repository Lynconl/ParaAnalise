﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Trabalho_Sudoku
{
    public partial class FormPrincipal : Form
    {
        int Segundos = 0, minutos, horas, Sorteio, t;
        int[,] Matriz = new int[9, 9];
        List<int> Sorteados = new List<int>();
        int[,] Conferir = new int[9, 9];

        public FormPrincipal()
        {
            InitializeComponent();

            for(int d=0; d < 9; d++) //MontarGrid
            {
                dataGridView1.Rows.Add();              
            }
            for (int y = 0; y < 9; y++)
            {
                for (int k = 0; k < 9; k++)
                {
                    //Linhas 0 , 1 e 2
                    if (y < 3 && k < 3) //colunas 0, 1 e 2
                    {
                        dataGridView1.Rows[y].Cells[k].Style.BackColor = Color.Snow;
                    }
                    else
                    if (y < 3 && k > 2 && k < 6) //colunas 3, 4 e 5
                    {
                        dataGridView1.Rows[y].Cells[k].Style.BackColor = Color.LightGray;
                    }
                    else
                    if (y < 3 && k > 5 && k < 9) //colunas 6, 7 e 8
                    {
                        dataGridView1.Rows[y].Cells[k].Style.BackColor = Color.Snow;
                    }
                    //Linhas 3, 4 e 5
                    if (y > 2  && y < 6 && k < 3) //colunas 0, 1 e 2
                    {
                        dataGridView1.Rows[y].Cells[k].Style.BackColor = Color.LightGray;
                    }
                    else
                    if (y > 2 && y < 6 && k < 6) //colunas 3, 4 e 5
                    {
                        dataGridView1.Rows[y].Cells[k].Style.BackColor = Color.Snow;
                    }
                    else
                    if (y > 2 && y < 6 && k < 9) //colunas 6, 7 e 8
                    {
                        dataGridView1.Rows[y].Cells[k].Style.BackColor = Color.LightGray;
                    }
                    //Linhas 6, 7 e 8
                    if (y > 5 && y < 9 && k < 3) //colunas 0, 1 e 2
                    {
                        dataGridView1.Rows[y].Cells[k].Style.BackColor = Color.Snow;
                    }
                    else
                    if (y > 5 && y < 9 && k < 6) //colunas 3, 4 e 5
                    {
                        dataGridView1.Rows[y].Cells[k].Style.BackColor = Color.LightGray;
                    }
                    else
                    if (y > 5 && y < 9 && k < 9) //colunas 6, 7 e 8
                    {
                        dataGridView1.Rows[y].Cells[k].Style.BackColor = Color.Snow;
                    }

                }
            }
        }      
        
        private bool Validar(int linha, int coluna)
        {            
            for(int i = 0; i < 9; i++) //Para percorrer todas as linhas e colunas.
            {
                if(Matriz[linha,i] == Sorteio || Matriz[i,coluna] == Sorteio)
                {
                    return true; //Não pode inserir o número sorteado.
                }                    
            }

            linha = (linha / 3) * 3;
            coluna = (coluna / 3) *3;

            for(int t = linha; t < linha + 3; t++)
            {
                for(int y = coluna; y < coluna + 3; y++)
                {
                    if(Matriz[t,y] == Sorteio)
                    {
                        return true;
                    }
                }
            }

            return false; //Pode inserir.
        }
        private void GerarNumeros(int linha, int coluna)
        {   
            if(linha == 8 && coluna == 9) //Ponto de parada;
            {
                switch (comboBxNivel.SelectedIndex)
                {
                    case 0: //Modo iniciante
                        for(int i=0; i < 9; i+=3)
                        {
                            for (int j = 0; j < 9; j += 3)
                            {
                                dataGridView1.Rows[i].Cells[j].Value = "";
                            }
                        }
                    break;

                    case 1: //Modo regular
                        for (int i = 0; i < 9; i+=2)
                        {
                            for (int j = 0; j < 9; j += 3)
                            {
                                dataGridView1.Rows[i].Cells[j].Value = "";
                            }
                        }
                        break;

                    case 2: //Modo avancado
                        
                        dataGridView1.Rows[0].Cells[1].Value = ""; dataGridView1.Rows[0].Cells[2].Value = ""; dataGridView1.Rows[0].Cells[3].Value = ""; dataGridView1.Rows[0].Cells[8].Value = "";
                        dataGridView1.Rows[1].Cells[1].Value = ""; dataGridView1.Rows[1].Cells[4].Value = ""; dataGridView1.Rows[1].Cells[5].Value = ""; dataGridView1.Rows[1].Cells[7].Value = "";
                        dataGridView1.Rows[2].Cells[0].Value = ""; dataGridView1.Rows[2].Cells[2].Value = ""; dataGridView1.Rows[2].Cells[4].Value = ""; dataGridView1.Rows[2].Cells[6].Value = "";
                        dataGridView1.Rows[2].Cells[8].Value = ""; dataGridView1.Rows[3].Cells[2].Value = ""; dataGridView1.Rows[3].Cells[3].Value = ""; dataGridView1.Rows[3].Cells[5].Value = "";
                        dataGridView1.Rows[3].Cells[7].Value = ""; dataGridView1.Rows[4].Cells[0].Value = ""; dataGridView1.Rows[4].Cells[2].Value = ""; dataGridView1.Rows[4].Cells[4].Value = "";
                        dataGridView1.Rows[4].Cells[6].Value = ""; dataGridView1.Rows[4].Cells[8].Value = ""; dataGridView1.Rows[5].Cells[0].Value = ""; dataGridView1.Rows[5].Cells[1].Value = "";
                        dataGridView1.Rows[5].Cells[3].Value = ""; dataGridView1.Rows[5].Cells[4].Value = ""; dataGridView1.Rows[5].Cells[7].Value = ""; dataGridView1.Rows[6].Cells[0].Value = "";
                        dataGridView1.Rows[6].Cells[1].Value = ""; dataGridView1.Rows[6].Cells[2].Value = ""; dataGridView1.Rows[6].Cells[6].Value = ""; dataGridView1.Rows[6].Cells[8].Value = "";
                        dataGridView1.Rows[7].Cells[3].Value = ""; dataGridView1.Rows[7].Cells[4].Value = ""; dataGridView1.Rows[7].Cells[5].Value = ""; dataGridView1.Rows[7].Cells[6].Value = "";
                        dataGridView1.Rows[7].Cells[8].Value = ""; dataGridView1.Rows[8].Cells[0].Value = ""; dataGridView1.Rows[8].Cells[2].Value = ""; dataGridView1.Rows[8].Cells[4].Value = "";
                        dataGridView1.Rows[8].Cells[6].Value = ""; dataGridView1.Rows[8].Cells[7].Value = "";
                        break;
                }
                return;
            }
            else
            {
                if (coluna == 9) //Vai para proxima linha e zera a coluna;
                {
                    linha++;
                    coluna = 0;
                }
                else
                {                    
                    Random nb = new Random();
                    Sorteio = nb.Next(1, 10);
                    t = 0;
                    while(Validar(linha, coluna) == true)
                    {
                        Sorteio = nb.Next(1, 10);
                        t++;
                        if(t >= 20)
                        {
                            for(int o = 0; o < 9; o++)
                            {
                                Matriz[linha, o] = 0;
                            }
                            coluna = 0;                            
                            break;
                        }                        
                    }     
                    if(t < 20)
                    {
                        Matriz[linha, coluna] = Sorteio;
                        dataGridView1.Rows[linha].Cells[coluna].Value = (Sorteio);
                        
                        //Thread.Sleep(100);
                        //MessageBox.Show(Sorteio.ToString());

                        coluna++;
                    }
                    
                }
                GerarNumeros(linha, coluna);
            }
        }

        private void timerTempo_Tick(object sender, EventArgs e)
        {
            if(timerTempo.Enabled == true)
            {
                Segundos += 1;

                if (Segundos < 10)
                {
                    lblSeg.Text = "0" + Segundos.ToString();
                }
                else
                {
                    lblSeg.Text = Segundos.ToString();
                }
                if (minutos == 59 & Segundos == 59)
                {
                    horas += 1;
                    minutos = 0;
                }
                if (Segundos == 59)
                {
                    minutos += 1;
                    Segundos = 0;
                }
                if (minutos < 10)
                {
                    lblMin.Text = "0" + minutos.ToString() + ":";
                }
                else
                {
                    lblMin.Text = minutos.ToString() + ":";
                }
                if (horas < 10)
                {
                    lblHora.Text = "0" + horas.ToString() + ":";
                }
                else
                {
                    lblHora.Text = horas.ToString() + ":";
                }                
            }     
           
        }

        private void bttnGerar_Click(object sender, EventArgs e)
        {
            if(comboBxNivel.Text == "Escolha um nível")
            {
                MessageBox.Show("Por gentileza, escolha um nível antes de dar início.", "Ops",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                dataGridView1.Visible = true;
                timerTempo.Enabled = true;
                lblTempoDecorrido.Visible = true;
                bttnGerar.Visible = false;
                comboBxNivel.Visible = false;
            }
            int linha=0, coluna=0;
            GerarNumeros(linha, coluna);
        }
    }
}
