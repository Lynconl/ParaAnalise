﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrabalhoCalendario
{
    public partial class FormFeriados : Form
    {
        public FormFeriados()
        {            
            InitializeComponent();            
        }
        
        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            int ano = Convert.ToInt32(maskedTextBoxAno.Text);

            if (ano < 1588)
            {
                MessageBox.Show("Data a partir(>) de 1587, de acordo com o decreto do papa Gregório XIII , em 24.02.1582",
                    "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                DateTime pascoa = Pascoa(ano);

                maskedTextBoxAno.Focus();
                richTextBox1.Clear();
                richTextBox1.AppendText("Confraternização Universal: " + DiaDaSemana(ano, 01, 01)
                    + ", " + new DateTime(ano, 01, 01).ToShortDateString() + Environment.NewLine + Environment.NewLine);

                int carnavalOrdinal = DataParaOrdinal(pascoa.Year, pascoa.Month, pascoa.Day) - 47;
                DateTime carnaval = OrdinalParaData(carnavalOrdinal, ano);
                richTextBox1.AppendText("Carnaval: " +
                    DiaDaSemana(carnaval.Year, carnaval.Month, carnaval.Day) +
                     ", " + carnaval.ToShortDateString() + Environment.NewLine + Environment.NewLine);

                int sextaSantaOrdinal = DataParaOrdinal(pascoa.Year, pascoa.Month, pascoa.Day) - 2;
                DateTime sextaSanta = OrdinalParaData(sextaSantaOrdinal, ano);
                richTextBox1.AppendText("Paixão de Cristo: " +
                    DiaDaSemana(sextaSanta.Year, sextaSanta.Month, sextaSanta.Day) +
                     ", " + sextaSanta.ToShortDateString() + Environment.NewLine + Environment.NewLine);

                richTextBox1.AppendText("Páscoa: " + DiaDaSemana(pascoa.Year, pascoa.Month, pascoa.Day) + ", " +
                    new DateTime(pascoa.Year, pascoa.Month, pascoa.Day).ToShortDateString() + Environment.NewLine + Environment.NewLine);

                richTextBox1.AppendText("Tiradentes: " + DiaDaSemana(ano, 04, 21) + ", " +
                    new DateTime(ano, 04, 21).ToShortDateString() + Environment.NewLine + Environment.NewLine);

                richTextBox1.AppendText("Dia do Trabalhador: " + DiaDaSemana(ano, 05, 01) + ", " +
                    new DateTime(ano, 05, 01).ToShortDateString() + Environment.NewLine + Environment.NewLine);

                int corpusChristiOrdinal = DataParaOrdinal(pascoa.Year, pascoa.Month, pascoa.Day) + 60;
                DateTime corpus = OrdinalParaData(corpusChristiOrdinal, ano);
                richTextBox1.AppendText("Corpus Christi: " +
                    DiaDaSemana(corpus.Year, corpus.Month, corpus.Day) +
                     ", " + corpus.ToShortDateString() + Environment.NewLine + Environment.NewLine);

                richTextBox1.AppendText("Dia da Pátria: " + DiaDaSemana(ano, 09, 07) + ", " +
                    new DateTime(ano, 09, 07).ToShortDateString() + Environment.NewLine + Environment.NewLine);

                richTextBox1.AppendText("Nossa Senhora da Aparecida: " + DiaDaSemana(ano, 10, 12) + ", " +
                    new DateTime(ano, 10, 12).ToShortDateString() + Environment.NewLine + Environment.NewLine);

                richTextBox1.AppendText("Finados: " + DiaDaSemana(ano, 11, 02) + ", " +
                    new DateTime(ano, 11, 02).ToShortDateString() + Environment.NewLine + Environment.NewLine);

                richTextBox1.AppendText("Proclamação da República: " + DiaDaSemana(ano, 11, 15) + ", " +
                    new DateTime(ano, 11, 15).ToShortDateString() + Environment.NewLine + Environment.NewLine);

                richTextBox1.AppendText("Natal: " + DiaDaSemana(ano, 12, 25) + ", " +
                    new DateTime(ano, 12, 25).ToShortDateString() + Environment.NewLine + Environment.NewLine);
            }
        }


        private string DiaDaSemana(double ano, double mes, double dia)
        {
            string[] Dias = new string[] { "Sábado", "Domingo", "Segunda-Feira", "Terça-Feira",
                "Quarta-Feira", "Quinta-Feira", "Sexta-Feira" };

            double a, b, c, d, e, f, g, h, i, j;

            a = (12 - mes) / 10;
            a = Math.Floor(a);
            b = ano - a;
            b = Math.Floor(b);
            c = mes + (12 * a);
            c = Math.Floor(c);
            d = b / 100;
            d = Math.Floor(d);
            e = d / 4;
            e = Math.Floor(e);
            f = 2 - d + e;
            f = Math.Floor(f);
            g = 365.25 * b;
            g = Math.Floor(g);
            h = 30.6001 * (c + 1);
            h = Math.Floor(h);
            i = (f + g) + (h + dia) + 5;
            i = Math.Floor(i);
            j = i % 7;


            return Dias[Convert.ToInt32(j)];
        }


        private DateTime Pascoa(double ano)
        {
            double x = 0;
            double y = 0;
            double dia, mes;

            if (ano >= 1582 & ano <= 1599)
            {
                x = 22;
                y = 2;
            }
            else
                if (ano >= 1600 & ano <= 1699)
            {
                x = 22;
                y = 2;
            }
            else
                if (ano >= 1700 & ano <= 1799)
            {
                x = 23;
                y = 3;
            }
            else
                if (ano >= 1800 & ano <= 1899)
            {
                x = 24;
                y = 4;
            }
            else
                if (ano >= 1900 & ano <= 2099)
            {
                x = 24;
                y = 5;
            }
            else
                if (ano >= 2100 & ano <= 2199)
            {
                x = 24;
                y = 6;
            }
            else
                if (ano >= 2200 & ano <= 2299)
            {
                x = 25;
                y = 7;
            }
            else

            {
                x = 24;
                y = 5;
            }

            double a, b, c, d, e;


            a = ano % 19;
            b = ano % 4;
            c = ano % 7;
            d = (19 * a + x) % 30;
            e = (2 * b + 4 * c + 6 * d + y) % 7;


            if ((d + e) > 9)
            {
                dia = (d + e - 9);
                mes = 4;
            }
            else
            {
                dia = (d + e + 22);
                mes = 3;
            }
            return new DateTime((int)ano, (int)mes, (int)dia);

        }

        private Boolean Bissexto(int ano)
        {
            if (ano % 4 == 0 && ano % 100 != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private int[] GeraTabelaMeses(int ano)
        {
            int[] mes = new int[13];

            mes[0] = 0;
            mes[1] = 31; //Jan
            mes[2] = 28; //Fev
            mes[3] = 31; //Mar
            mes[4] = 30; //Abr
            mes[5] = 31; //Maio
            mes[6] = 30; //Jun
            mes[7] = 31; //Jul
            mes[8] = 31; //Ago
            mes[9] = 30; //Set
            mes[10] = 31; //Out
            mes[11] = 30; //Nov
            mes[12] = 31; //Dez

            if (Bissexto(ano) == true) // Verifica se ano é bissexto, se sim..
            {
                mes[2] = 29; // Ano bissexto, logo Fevereiro tem 29 dias.
                return mes;
            }
            else // Se não..
            {
                return mes;
            }

        }

        private int[] GeraTabelaOrdinais(int ano)
        {
            int[] mes = GeraTabelaMeses(ano);
            int[] Ordinais = new int[13];

            for (int x = 0; x <= 12; x++)
            {
                if (x == 0)
                {
                    Ordinais[x] = 0;
                }
                else
                {
                    Ordinais[x] = mes[x] + Ordinais[x - 1];
                }
            }
            return Ordinais;
        }

        private int DataParaOrdinal(int ano, int mes, int dia)
        {
            int[] Ordinais = GeraTabelaOrdinais(ano);

            return (Ordinais[mes - 1] + dia);
        }

        private DateTime OrdinalParaData(int diaOrdinal, int ano)
        {
            int[] Ordinais = GeraTabelaOrdinais(ano);            
            int dia=0, mes=0;

            for (int d = 0; d < 12; d++)
            {              
                if (diaOrdinal > Ordinais[d])
                {
                    dia = diaOrdinal - Ordinais[d];
                    mes = d + 1;
                }                
            }            
            return new DateTime(ano, mes, dia);

        }
    }
}

