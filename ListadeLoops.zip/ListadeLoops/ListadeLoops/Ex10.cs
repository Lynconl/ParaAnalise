﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex10 : Form
    {
        public Ex10()
        {
            InitializeComponent();
        }

        private void bttnVerificar_Click(object sender, EventArgs e)
        {
            double N;
            int Y = 0;

            N = (double)numericUDValorInformado.Value;
            //Variável que que será testada

            for (double i = 1; i <= N; i++)
            {
                string valorVerificar = Convert.ToString(N / i);

                //Variável que terá o valor, caso seja inteiro
                int valorInteiro;

                //Validando se é inteiro utilizando o recurso TryParse
                //No método passamos primeiro uma string, e depois a saída "out"
                bool isNumeroInteiro = int.TryParse(valorVerificar, out valorInteiro);

                //Verificando se é um número
                if (isNumeroInteiro)
                {
                    Y += 1;                    
                }                
            }           
            
            if (Y == 2 || N == 1)
            {
                MessageBox.Show("  É Primo" , "Resultado" , MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("  Não Primo", "Resultado", MessageBoxButtons.OK);
            }

        }
    }
}
