﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex8 : Form
    {
        public Ex8()
        {
            InitializeComponent();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void bttnVerificar_Click(object sender, EventArgs e)
        {
            richTextBox1.Visible = true;
            richTextBox1.Clear();

            int InterDE, InterATE, DividirPOR, N;

            InterDE = (int)numericUDDE.Value;
            InterATE = (int)numericUDAte.Value;
            DividirPOR = (int)numericUDDividir.Value;

            for (int i = InterDE; i <= InterATE; i++)
            {
                N = i % DividirPOR;

                    if (N == 0)
                    {
                        richTextBox1.AppendText("--> " + i);
                        richTextBox1.AppendText(Environment.NewLine);
                        richTextBox1.ScrollToCaret();
                    }
            }
        }
    }
}
