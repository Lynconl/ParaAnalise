﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex1 : Form
    {
        public Ex1()
        {
            InitializeComponent();
        }

        private void bttnExibir_Click(object sender, EventArgs e)
        {            
            for (int x = 0; x <= 10; x++)
            {
                richTxtBxTela.AppendText("Valor: " + x);
                richTxtBxTela.AppendText(Environment.NewLine);
            }
        }
    }
}
