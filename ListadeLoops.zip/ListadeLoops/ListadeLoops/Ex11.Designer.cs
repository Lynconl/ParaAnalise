﻿namespace ListadeLoops
{
    partial class Ex11
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblN = new System.Windows.Forms.Label();
            this.numericUDValordeN = new System.Windows.Forms.NumericUpDown();
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            this.bttnCalcular = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDValordeN)).BeginInit();
            this.SuspendLayout();
            // 
            // lblN
            // 
            this.lblN.AutoSize = true;
            this.lblN.Location = new System.Drawing.Point(12, 17);
            this.lblN.Name = "lblN";
            this.lblN.Size = new System.Drawing.Size(76, 18);
            this.lblN.TabIndex = 0;
            this.lblN.Text = "Informe N:";
            // 
            // numericUDValordeN
            // 
            this.numericUDValordeN.Location = new System.Drawing.Point(107, 15);
            this.numericUDValordeN.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUDValordeN.Name = "numericUDValordeN";
            this.numericUDValordeN.Size = new System.Drawing.Size(144, 26);
            this.numericUDValordeN.TabIndex = 1;
            this.numericUDValordeN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDValordeN.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.Location = new System.Drawing.Point(3, 51);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.Size = new System.Drawing.Size(341, 182);
            this.richTxtBxTela.TabIndex = 2;
            this.richTxtBxTela.Text = "";
            // 
            // bttnCalcular
            // 
            this.bttnCalcular.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnCalcular.Location = new System.Drawing.Point(259, 7);
            this.bttnCalcular.Name = "bttnCalcular";
            this.bttnCalcular.Size = new System.Drawing.Size(85, 38);
            this.bttnCalcular.TabIndex = 3;
            this.bttnCalcular.Text = "Calcular";
            this.bttnCalcular.UseVisualStyleBackColor = false;
            this.bttnCalcular.Click += new System.EventHandler(this.bttnCalcular_Click);
            // 
            // Ex11
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 236);
            this.Controls.Add(this.bttnCalcular);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.numericUDValordeN);
            this.Controls.Add(this.lblN);
            this.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "Ex11";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex11";
            ((System.ComponentModel.ISupportInitialize)(this.numericUDValordeN)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblN;
        private System.Windows.Forms.NumericUpDown numericUDValordeN;
        private System.Windows.Forms.RichTextBox richTxtBxTela;
        private System.Windows.Forms.Button bttnCalcular;
    }
}