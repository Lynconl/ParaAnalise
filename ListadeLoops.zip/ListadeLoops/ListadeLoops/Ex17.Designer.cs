﻿namespace ListadeLoops
{
    partial class Ex17
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            this.bttnMostrar = new System.Windows.Forms.Button();
            this.numericUDNL = new System.Windows.Forms.NumericUpDown();
            this.lblNLinhas = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDNL)).BeginInit();
            this.SuspendLayout();
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.Location = new System.Drawing.Point(12, 55);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.Size = new System.Drawing.Size(369, 295);
            this.richTxtBxTela.TabIndex = 11;
            this.richTxtBxTela.Text = "";
            // 
            // bttnMostrar
            // 
            this.bttnMostrar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnMostrar.Location = new System.Drawing.Point(298, 8);
            this.bttnMostrar.Name = "bttnMostrar";
            this.bttnMostrar.Size = new System.Drawing.Size(83, 41);
            this.bttnMostrar.TabIndex = 10;
            this.bttnMostrar.Text = "Mostrar";
            this.bttnMostrar.UseVisualStyleBackColor = false;
            this.bttnMostrar.Click += new System.EventHandler(this.bttnMostrar_Click);
            // 
            // numericUDNL
            // 
            this.numericUDNL.Location = new System.Drawing.Point(161, 15);
            this.numericUDNL.Name = "numericUDNL";
            this.numericUDNL.Size = new System.Drawing.Size(120, 20);
            this.numericUDNL.TabIndex = 9;
            this.numericUDNL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDNL.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // lblNLinhas
            // 
            this.lblNLinhas.AutoSize = true;
            this.lblNLinhas.Location = new System.Drawing.Point(12, 17);
            this.lblNLinhas.Name = "lblNLinhas";
            this.lblNLinhas.Size = new System.Drawing.Size(93, 13);
            this.lblNLinhas.TabIndex = 8;
            this.lblNLinhas.Text = "Informe N(Linhas):";
            // 
            // Ex17
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(392, 364);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.bttnMostrar);
            this.Controls.Add(this.numericUDNL);
            this.Controls.Add(this.lblNLinhas);
            this.MaximizeBox = false;
            this.Name = "Ex17";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex17";
            ((System.ComponentModel.ISupportInitialize)(this.numericUDNL)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTxtBxTela;
        private System.Windows.Forms.Button bttnMostrar;
        private System.Windows.Forms.NumericUpDown numericUDNL;
        private System.Windows.Forms.Label lblNLinhas;
    }
}