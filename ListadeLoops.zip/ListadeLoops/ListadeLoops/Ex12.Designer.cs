﻿namespace ListadeLoops
{
    partial class Ex12
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttnCalcular = new System.Windows.Forms.Button();
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            this.numericUDValordeN = new System.Windows.Forms.NumericUpDown();
            this.lbln = new System.Windows.Forms.Label();
            this.lbln2 = new System.Windows.Forms.Label();
            this.numericUDValordeN2 = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDValordeN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDValordeN2)).BeginInit();
            this.SuspendLayout();
            // 
            // bttnCalcular
            // 
            this.bttnCalcular.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnCalcular.Location = new System.Drawing.Point(358, 2);
            this.bttnCalcular.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bttnCalcular.Name = "bttnCalcular";
            this.bttnCalcular.Size = new System.Drawing.Size(113, 96);
            this.bttnCalcular.TabIndex = 7;
            this.bttnCalcular.Text = "Calcular";
            this.bttnCalcular.UseVisualStyleBackColor = false;
            this.bttnCalcular.Click += new System.EventHandler(this.bttnCalcular_Click);
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.Location = new System.Drawing.Point(16, 106);
            this.richTxtBxTela.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.Size = new System.Drawing.Size(453, 208);
            this.richTxtBxTela.TabIndex = 6;
            this.richTxtBxTela.Text = "";
            // 
            // numericUDValordeN
            // 
            this.numericUDValordeN.Location = new System.Drawing.Point(154, 14);
            this.numericUDValordeN.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUDValordeN.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUDValordeN.Name = "numericUDValordeN";
            this.numericUDValordeN.Size = new System.Drawing.Size(192, 26);
            this.numericUDValordeN.TabIndex = 5;
            this.numericUDValordeN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDValordeN.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // lbln
            // 
            this.lbln.AutoSize = true;
            this.lbln.Location = new System.Drawing.Point(27, 17);
            this.lbln.Name = "lbln";
            this.lbln.Size = new System.Drawing.Size(73, 18);
            this.lbln.TabIndex = 4;
            this.lbln.Text = "Informe n:";
            // 
            // lbln2
            // 
            this.lbln2.AutoSize = true;
            this.lbln2.Location = new System.Drawing.Point(27, 65);
            this.lbln2.Name = "lbln2";
            this.lbln2.Size = new System.Drawing.Size(76, 18);
            this.lbln2.TabIndex = 8;
            this.lbln2.Text = "Informe N:";
            // 
            // numericUDValordeN2
            // 
            this.numericUDValordeN2.Location = new System.Drawing.Point(154, 63);
            this.numericUDValordeN2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUDValordeN2.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUDValordeN2.Name = "numericUDValordeN2";
            this.numericUDValordeN2.Size = new System.Drawing.Size(192, 26);
            this.numericUDValordeN2.TabIndex = 9;
            this.numericUDValordeN2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDValordeN2.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // Ex12
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(480, 322);
            this.Controls.Add(this.numericUDValordeN2);
            this.Controls.Add(this.lbln2);
            this.Controls.Add(this.bttnCalcular);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.numericUDValordeN);
            this.Controls.Add(this.lbln);
            this.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Ex12";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex12";
            ((System.ComponentModel.ISupportInitialize)(this.numericUDValordeN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDValordeN2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttnCalcular;
        private System.Windows.Forms.RichTextBox richTxtBxTela;
        private System.Windows.Forms.NumericUpDown numericUDValordeN;
        private System.Windows.Forms.Label lbln;
        private System.Windows.Forms.Label lbln2;
        private System.Windows.Forms.NumericUpDown numericUDValordeN2;
    }
}