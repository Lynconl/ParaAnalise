﻿namespace ListadeLoops
{
    partial class Ex7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInterloDe = new System.Windows.Forms.Label();
            this.numericUDInterloDE = new System.Windows.Forms.NumericUpDown();
            this.bttnVerificar = new System.Windows.Forms.Button();
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            this.lblIntervaloAte = new System.Windows.Forms.Label();
            this.numericUDIntervaloATE = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDInterloDE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDIntervaloATE)).BeginInit();
            this.SuspendLayout();
            // 
            // lblInterloDe
            // 
            this.lblInterloDe.AutoSize = true;
            this.lblInterloDe.Location = new System.Drawing.Point(12, 9);
            this.lblInterloDe.Name = "lblInterloDe";
            this.lblInterloDe.Size = new System.Drawing.Size(87, 18);
            this.lblInterloDe.TabIndex = 0;
            this.lblInterloDe.Text = "Intervalo de:";
            // 
            // numericUDInterloDE
            // 
            this.numericUDInterloDE.Location = new System.Drawing.Point(126, 7);
            this.numericUDInterloDE.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numericUDInterloDE.Minimum = new decimal(new int[] {
            99999,
            0,
            0,
            -2147483648});
            this.numericUDInterloDE.Name = "numericUDInterloDE";
            this.numericUDInterloDE.Size = new System.Drawing.Size(120, 26);
            this.numericUDInterloDE.TabIndex = 1;
            this.numericUDInterloDE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDInterloDE.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // bttnVerificar
            // 
            this.bttnVerificar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnVerificar.Location = new System.Drawing.Point(261, 7);
            this.bttnVerificar.Name = "bttnVerificar";
            this.bttnVerificar.Size = new System.Drawing.Size(75, 74);
            this.bttnVerificar.TabIndex = 2;
            this.bttnVerificar.Text = "Verificar";
            this.bttnVerificar.UseVisualStyleBackColor = false;
            this.bttnVerificar.Click += new System.EventHandler(this.bttnVerificar_Click);
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.Location = new System.Drawing.Point(15, 99);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.Size = new System.Drawing.Size(321, 233);
            this.richTxtBxTela.TabIndex = 3;
            this.richTxtBxTela.Text = "";
            // 
            // lblIntervaloAte
            // 
            this.lblIntervaloAte.AutoSize = true;
            this.lblIntervaloAte.Location = new System.Drawing.Point(12, 57);
            this.lblIntervaloAte.Name = "lblIntervaloAte";
            this.lblIntervaloAte.Size = new System.Drawing.Size(91, 18);
            this.lblIntervaloAte.TabIndex = 4;
            this.lblIntervaloAte.Text = "Intervalo até:";
            // 
            // numericUDIntervaloATE
            // 
            this.numericUDIntervaloATE.Location = new System.Drawing.Point(126, 55);
            this.numericUDIntervaloATE.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numericUDIntervaloATE.Minimum = new decimal(new int[] {
            99999,
            0,
            0,
            -2147483648});
            this.numericUDIntervaloATE.Name = "numericUDIntervaloATE";
            this.numericUDIntervaloATE.Size = new System.Drawing.Size(120, 26);
            this.numericUDIntervaloATE.TabIndex = 5;
            this.numericUDIntervaloATE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDIntervaloATE.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // Ex7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(355, 344);
            this.Controls.Add(this.numericUDIntervaloATE);
            this.Controls.Add(this.lblIntervaloAte);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.bttnVerificar);
            this.Controls.Add(this.numericUDInterloDE);
            this.Controls.Add(this.lblInterloDe);
            this.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Ex7";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex7";
            ((System.ComponentModel.ISupportInitialize)(this.numericUDInterloDE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDIntervaloATE)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInterloDe;
        private System.Windows.Forms.NumericUpDown numericUDInterloDE;
        private System.Windows.Forms.Button bttnVerificar;
        private System.Windows.Forms.RichTextBox richTxtBxTela;
        private System.Windows.Forms.Label lblIntervaloAte;
        private System.Windows.Forms.NumericUpDown numericUDIntervaloATE;
    }
}