﻿namespace ListadeLoops
{
    partial class Ex2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttnCalcular = new System.Windows.Forms.Button();
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            this.bttnHelp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bttnCalcular
            // 
            this.bttnCalcular.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnCalcular.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnCalcular.Location = new System.Drawing.Point(12, 12);
            this.bttnCalcular.Name = "bttnCalcular";
            this.bttnCalcular.Size = new System.Drawing.Size(97, 33);
            this.bttnCalcular.TabIndex = 0;
            this.bttnCalcular.Text = "Calcular";
            this.bttnCalcular.UseVisualStyleBackColor = false;
            this.bttnCalcular.Click += new System.EventHandler(this.bttnCalcular_Click);
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.BackColor = System.Drawing.Color.White;
            this.richTxtBxTela.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTxtBxTela.ForeColor = System.Drawing.Color.DarkGreen;
            this.richTxtBxTela.Location = new System.Drawing.Point(12, 56);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.Size = new System.Drawing.Size(194, 240);
            this.richTxtBxTela.TabIndex = 1;
            this.richTxtBxTela.Text = "";
            // 
            // bttnHelp
            // 
            this.bttnHelp.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnHelp.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnHelp.Location = new System.Drawing.Point(151, 12);
            this.bttnHelp.Name = "bttnHelp";
            this.bttnHelp.Size = new System.Drawing.Size(54, 33);
            this.bttnHelp.TabIndex = 2;
            this.bttnHelp.Text = "HELP";
            this.bttnHelp.UseVisualStyleBackColor = false;
            this.bttnHelp.Click += new System.EventHandler(this.bttnHelp_Click);
            // 
            // Ex2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(217, 308);
            this.Controls.Add(this.bttnHelp);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.bttnCalcular);
            this.MaximizeBox = false;
            this.Name = "Ex2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bttnCalcular;
        private System.Windows.Forms.RichTextBox richTxtBxTela;
        private System.Windows.Forms.Button bttnHelp;
    }
}