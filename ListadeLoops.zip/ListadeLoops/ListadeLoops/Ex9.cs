﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex9 : Form
    {
        public static double Numerador, Denominador, Soma1, x = 2, i = 0, Soma2;
        public Ex9()
        {
            InitializeComponent();
        }

        private void bttnCalcular_Click(object sender, EventArgs e)
        {            
            
            for (int i = 500; i >= 20; i = i - 20)
            {
                Numerador = i;

                for (double z = x; z <= 26; z++)
                {
                    Denominador = x;
                    Soma1 = Numerador / Denominador;
                    Soma2 += Soma1;
                    if (x <= 4)
                    {
                        x = x * 2;
                    }
                    else if (x < 26)
                    {
                        x += 1;
                    }
                    else
                    {
                        x = 26;
                    }

                    break;
                }
            }
            richTxtBxTela.AppendText("Resultado: " + Soma2);
            richTxtBxTela.AppendText(Environment.NewLine);
            x = 2; i = 0; Soma1 = 0; Soma2 = 0; Numerador = 0; Denominador = 0;            

            
        }       
    }
}
