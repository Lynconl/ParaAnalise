﻿namespace ListadeLoops
{
    partial class FormListaExercicios
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttn1 = new System.Windows.Forms.Button();
            this.bttn2 = new System.Windows.Forms.Button();
            this.bttn3 = new System.Windows.Forms.Button();
            this.bttn4 = new System.Windows.Forms.Button();
            this.bttn5 = new System.Windows.Forms.Button();
            this.bttn6 = new System.Windows.Forms.Button();
            this.bttn7 = new System.Windows.Forms.Button();
            this.bttn8 = new System.Windows.Forms.Button();
            this.bttn9 = new System.Windows.Forms.Button();
            this.bttn10 = new System.Windows.Forms.Button();
            this.bttn11 = new System.Windows.Forms.Button();
            this.bttn12 = new System.Windows.Forms.Button();
            this.bttn14 = new System.Windows.Forms.Button();
            this.bttn13 = new System.Windows.Forms.Button();
            this.bttn15 = new System.Windows.Forms.Button();
            this.bttn16 = new System.Windows.Forms.Button();
            this.bttn17 = new System.Windows.Forms.Button();
            this.bttn18 = new System.Windows.Forms.Button();
            this.bttn19 = new System.Windows.Forms.Button();
            this.lblLynconl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bttn1
            // 
            this.bttn1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn1.Location = new System.Drawing.Point(12, 12);
            this.bttn1.Name = "bttn1";
            this.bttn1.Size = new System.Drawing.Size(43, 31);
            this.bttn1.TabIndex = 0;
            this.bttn1.Text = "1";
            this.bttn1.UseVisualStyleBackColor = false;
            this.bttn1.Click += new System.EventHandler(this.bttn1_Click);
            // 
            // bttn2
            // 
            this.bttn2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn2.Location = new System.Drawing.Point(61, 12);
            this.bttn2.Name = "bttn2";
            this.bttn2.Size = new System.Drawing.Size(43, 31);
            this.bttn2.TabIndex = 1;
            this.bttn2.Text = "2";
            this.bttn2.UseVisualStyleBackColor = false;
            this.bttn2.Click += new System.EventHandler(this.bttn2_Click);
            // 
            // bttn3
            // 
            this.bttn3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn3.Location = new System.Drawing.Point(110, 12);
            this.bttn3.Name = "bttn3";
            this.bttn3.Size = new System.Drawing.Size(43, 31);
            this.bttn3.TabIndex = 2;
            this.bttn3.Text = "3";
            this.bttn3.UseVisualStyleBackColor = false;
            this.bttn3.Click += new System.EventHandler(this.bttn3_Click);
            // 
            // bttn4
            // 
            this.bttn4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn4.Location = new System.Drawing.Point(159, 12);
            this.bttn4.Name = "bttn4";
            this.bttn4.Size = new System.Drawing.Size(43, 31);
            this.bttn4.TabIndex = 3;
            this.bttn4.Text = "4";
            this.bttn4.UseVisualStyleBackColor = false;
            this.bttn4.Click += new System.EventHandler(this.bttn4_Click);
            // 
            // bttn5
            // 
            this.bttn5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn5.Location = new System.Drawing.Point(208, 12);
            this.bttn5.Name = "bttn5";
            this.bttn5.Size = new System.Drawing.Size(43, 31);
            this.bttn5.TabIndex = 4;
            this.bttn5.Text = "5";
            this.bttn5.UseVisualStyleBackColor = false;
            this.bttn5.Click += new System.EventHandler(this.bttn5_Click);
            // 
            // bttn6
            // 
            this.bttn6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn6.Location = new System.Drawing.Point(12, 49);
            this.bttn6.Name = "bttn6";
            this.bttn6.Size = new System.Drawing.Size(43, 31);
            this.bttn6.TabIndex = 5;
            this.bttn6.Text = "6";
            this.bttn6.UseVisualStyleBackColor = false;
            this.bttn6.Click += new System.EventHandler(this.bttn6_Click);
            // 
            // bttn7
            // 
            this.bttn7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn7.Location = new System.Drawing.Point(61, 49);
            this.bttn7.Name = "bttn7";
            this.bttn7.Size = new System.Drawing.Size(43, 31);
            this.bttn7.TabIndex = 6;
            this.bttn7.Text = "7";
            this.bttn7.UseVisualStyleBackColor = false;
            this.bttn7.Click += new System.EventHandler(this.bttn7_Click);
            // 
            // bttn8
            // 
            this.bttn8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn8.Location = new System.Drawing.Point(110, 49);
            this.bttn8.Name = "bttn8";
            this.bttn8.Size = new System.Drawing.Size(43, 31);
            this.bttn8.TabIndex = 7;
            this.bttn8.Text = "8";
            this.bttn8.UseVisualStyleBackColor = false;
            this.bttn8.Click += new System.EventHandler(this.bttn8_Click);
            // 
            // bttn9
            // 
            this.bttn9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn9.Location = new System.Drawing.Point(159, 49);
            this.bttn9.Name = "bttn9";
            this.bttn9.Size = new System.Drawing.Size(43, 31);
            this.bttn9.TabIndex = 8;
            this.bttn9.Text = "9";
            this.bttn9.UseVisualStyleBackColor = false;
            this.bttn9.Click += new System.EventHandler(this.bttn9_Click);
            // 
            // bttn10
            // 
            this.bttn10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn10.Location = new System.Drawing.Point(208, 49);
            this.bttn10.Name = "bttn10";
            this.bttn10.Size = new System.Drawing.Size(43, 31);
            this.bttn10.TabIndex = 9;
            this.bttn10.Text = "10";
            this.bttn10.UseVisualStyleBackColor = false;
            this.bttn10.Click += new System.EventHandler(this.bttn10_Click);
            // 
            // bttn11
            // 
            this.bttn11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn11.Location = new System.Drawing.Point(12, 86);
            this.bttn11.Name = "bttn11";
            this.bttn11.Size = new System.Drawing.Size(43, 31);
            this.bttn11.TabIndex = 10;
            this.bttn11.Text = "11";
            this.bttn11.UseVisualStyleBackColor = false;
            this.bttn11.Click += new System.EventHandler(this.bttn11_Click);
            // 
            // bttn12
            // 
            this.bttn12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn12.Location = new System.Drawing.Point(61, 86);
            this.bttn12.Name = "bttn12";
            this.bttn12.Size = new System.Drawing.Size(43, 31);
            this.bttn12.TabIndex = 11;
            this.bttn12.Text = "12";
            this.bttn12.UseVisualStyleBackColor = false;
            this.bttn12.Click += new System.EventHandler(this.bttn12_Click);
            // 
            // bttn14
            // 
            this.bttn14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn14.Location = new System.Drawing.Point(159, 86);
            this.bttn14.Name = "bttn14";
            this.bttn14.Size = new System.Drawing.Size(43, 31);
            this.bttn14.TabIndex = 12;
            this.bttn14.Text = "14";
            this.bttn14.UseVisualStyleBackColor = false;
            this.bttn14.Click += new System.EventHandler(this.bttn14_Click);
            // 
            // bttn13
            // 
            this.bttn13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn13.Location = new System.Drawing.Point(110, 86);
            this.bttn13.Name = "bttn13";
            this.bttn13.Size = new System.Drawing.Size(43, 31);
            this.bttn13.TabIndex = 13;
            this.bttn13.Text = "13";
            this.bttn13.UseVisualStyleBackColor = false;
            this.bttn13.Click += new System.EventHandler(this.bttn13_Click);
            // 
            // bttn15
            // 
            this.bttn15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn15.Location = new System.Drawing.Point(208, 86);
            this.bttn15.Name = "bttn15";
            this.bttn15.Size = new System.Drawing.Size(43, 31);
            this.bttn15.TabIndex = 14;
            this.bttn15.Text = "15";
            this.bttn15.UseVisualStyleBackColor = false;
            this.bttn15.Click += new System.EventHandler(this.bttn15_Click);
            // 
            // bttn16
            // 
            this.bttn16.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn16.Location = new System.Drawing.Point(12, 123);
            this.bttn16.Name = "bttn16";
            this.bttn16.Size = new System.Drawing.Size(43, 31);
            this.bttn16.TabIndex = 15;
            this.bttn16.Text = "16";
            this.bttn16.UseVisualStyleBackColor = false;
            this.bttn16.Click += new System.EventHandler(this.bttn16_Click);
            // 
            // bttn17
            // 
            this.bttn17.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn17.Location = new System.Drawing.Point(61, 123);
            this.bttn17.Name = "bttn17";
            this.bttn17.Size = new System.Drawing.Size(43, 31);
            this.bttn17.TabIndex = 16;
            this.bttn17.Text = "17";
            this.bttn17.UseVisualStyleBackColor = false;
            this.bttn17.Click += new System.EventHandler(this.bttn17_Click);
            // 
            // bttn18
            // 
            this.bttn18.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn18.Location = new System.Drawing.Point(110, 123);
            this.bttn18.Name = "bttn18";
            this.bttn18.Size = new System.Drawing.Size(43, 31);
            this.bttn18.TabIndex = 17;
            this.bttn18.Text = "18";
            this.bttn18.UseVisualStyleBackColor = false;
            this.bttn18.Click += new System.EventHandler(this.bttn18_Click);
            // 
            // bttn19
            // 
            this.bttn19.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn19.Location = new System.Drawing.Point(159, 123);
            this.bttn19.Name = "bttn19";
            this.bttn19.Size = new System.Drawing.Size(43, 31);
            this.bttn19.TabIndex = 18;
            this.bttn19.Text = "19";
            this.bttn19.UseVisualStyleBackColor = false;
            this.bttn19.Click += new System.EventHandler(this.bttn19_Click);
            // 
            // lblLynconl
            // 
            this.lblLynconl.AutoSize = true;
            this.lblLynconl.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLynconl.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblLynconl.Location = new System.Drawing.Point(48, 165);
            this.lblLynconl.Name = "lblLynconl";
            this.lblLynconl.Size = new System.Drawing.Size(203, 15);
            this.lblLynconl.TabIndex = 19;
            this.lblLynconl.Text = "Desenvolvido por: Lynconl F. Assunção";
            // 
            // FormListaExercicios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(262, 189);
            this.Controls.Add(this.lblLynconl);
            this.Controls.Add(this.bttn19);
            this.Controls.Add(this.bttn18);
            this.Controls.Add(this.bttn17);
            this.Controls.Add(this.bttn16);
            this.Controls.Add(this.bttn15);
            this.Controls.Add(this.bttn13);
            this.Controls.Add(this.bttn14);
            this.Controls.Add(this.bttn12);
            this.Controls.Add(this.bttn11);
            this.Controls.Add(this.bttn10);
            this.Controls.Add(this.bttn9);
            this.Controls.Add(this.bttn8);
            this.Controls.Add(this.bttn7);
            this.Controls.Add(this.bttn6);
            this.Controls.Add(this.bttn5);
            this.Controls.Add(this.bttn4);
            this.Controls.Add(this.bttn3);
            this.Controls.Add(this.bttn2);
            this.Controls.Add(this.bttn1);
            this.MaximizeBox = false;
            this.Name = "FormListaExercicios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lista Exercícios";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttn1;
        private System.Windows.Forms.Button bttn2;
        private System.Windows.Forms.Button bttn3;
        private System.Windows.Forms.Button bttn4;
        private System.Windows.Forms.Button bttn5;
        private System.Windows.Forms.Button bttn6;
        private System.Windows.Forms.Button bttn7;
        private System.Windows.Forms.Button bttn8;
        private System.Windows.Forms.Button bttn9;
        private System.Windows.Forms.Button bttn10;
        private System.Windows.Forms.Button bttn11;
        private System.Windows.Forms.Button bttn12;
        private System.Windows.Forms.Button bttn14;
        private System.Windows.Forms.Button bttn13;
        private System.Windows.Forms.Button bttn15;
        private System.Windows.Forms.Button bttn16;
        private System.Windows.Forms.Button bttn17;
        private System.Windows.Forms.Button bttn18;
        private System.Windows.Forms.Button bttn19;
        private System.Windows.Forms.Label lblLynconl;
    }
}

