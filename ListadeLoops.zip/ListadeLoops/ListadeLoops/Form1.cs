﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class FormListaExercicios : Form
    {
        public FormListaExercicios()
        {
            InitializeComponent();
        }

        private void bttn1_Click(object sender, EventArgs e)
        {
            Ex1 ex = new Ex1();
            ex.Show();
        }

        private void bttn2_Click(object sender, EventArgs e)
        {
            Ex2 ex = new Ex2();
            ex.Show();
        }

        private void bttn3_Click(object sender, EventArgs e)
        {
            Ex3 ex = new Ex3();
            ex.Show();
        }

        private void bttn4_Click(object sender, EventArgs e)
        {
            Ex4 ex = new Ex4();
            ex.Show();
        }

        private void bttn5_Click(object sender, EventArgs e)
        {
            Ex5 ex = new Ex5();
            ex.Show();
        }

        private void bttn6_Click(object sender, EventArgs e)
        {
            Ex6 ex = new Ex6();
            ex.Show();
        }

        private void bttn7_Click(object sender, EventArgs e)
        {
            Ex7 ex = new Ex7();
            ex.Show();
        }

        private void bttn8_Click(object sender, EventArgs e)
        {
            Ex8 ex = new Ex8();
            ex.Show();
        }

        private void bttn9_Click(object sender, EventArgs e)
        {
            Ex9 ex = new Ex9();
            ex.Show();
        }

        private void bttn10_Click(object sender, EventArgs e)
        {
            Ex10 ex = new Ex10();
            ex.Show();
        }

        private void bttn11_Click(object sender, EventArgs e)
        {
            Ex11 ex = new Ex11();
            ex.Show();
        }

        private void bttn12_Click(object sender, EventArgs e)
        {
            Ex12 ex = new Ex12();
            ex.Show();
        }

        private void bttn13_Click(object sender, EventArgs e)
        {
            Ex13 ex = new Ex13();
            ex.Show();
        }

        private void bttn14_Click(object sender, EventArgs e)
        {
            Ex14 ex = new Ex14();
            ex.Show();
        }

        private void bttn15_Click(object sender, EventArgs e)
        {
            Ex15 ex = new Ex15();
            ex.Show();
        }

        private void bttn16_Click(object sender, EventArgs e)
        {
            Ex16 ex = new Ex16();
            ex.Show();
        }

        private void bttn17_Click(object sender, EventArgs e)
        {
            Ex17 ex = new Ex17();
            ex.Show();
        }

        private void bttn18_Click(object sender, EventArgs e)
        {
            Ex18 ex = new Ex18();
            ex.Show();
        }

        private void bttn19_Click(object sender, EventArgs e)
        {
            Ex19 ex = new Ex19();
            ex.Show();
        }
    }
}
