﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex17 : Form
    {
        public Ex17()
        {
            InitializeComponent();
        }

        private void bttnMostrar_Click(object sender, EventArgs e)
        {
            int N;

            N = (int)numericUDNL.Value;

            for (int i = 1; i <= N; i++)
            {
                richTxtBxTela.AppendText(Environment.NewLine);
               
                    for (int x = 0; x <= i; x++)
                    {
                        x += i + 1;
                        richTxtBxTela.AppendText((x).ToString());
                    
                    }                
            }
        }
    }
}
