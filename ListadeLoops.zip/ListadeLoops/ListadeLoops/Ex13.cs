﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex13 : Form
    {
        public Ex13()
        {
            InitializeComponent();
        }

        private void Ex13_Load(object sender, EventArgs e)
        {

        }
    }
}
