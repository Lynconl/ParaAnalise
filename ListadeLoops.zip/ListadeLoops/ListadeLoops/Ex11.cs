﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex11 : Form
    {
        public Ex11()
        {
            InitializeComponent();
        }

        private void bttnCalcular_Click(object sender, EventArgs e)
        {
            richTxtBxTela.Clear();
            double N, N2, N3=0, X;

            N = (double)numericUDValordeN.Value;
            N2 = 1 / (1 + N);            

            for (int i = 1; i <= N; i++)
            {
                N3 += N * N2;
                X = N3 - (N * N2);
                richTxtBxTela.AppendText("Resultado de:  " + N + " x " + N2.ToString("N2") + " + " +
                    X.ToString("N4") + "   =   " + N3.ToString("N2"));
                richTxtBxTela.AppendText(Environment.NewLine);
                richTxtBxTela.ScrollToCaret();
                richTxtBxTela.Focus();
            }
            
        }
    }
}
