﻿namespace ListadeLoops
{
    partial class Ex6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttnCalcular = new System.Windows.Forms.Button();
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUDN = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDN)).BeginInit();
            this.SuspendLayout();
            // 
            // bttnCalcular
            // 
            this.bttnCalcular.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnCalcular.Location = new System.Drawing.Point(51, 72);
            this.bttnCalcular.Name = "bttnCalcular";
            this.bttnCalcular.Size = new System.Drawing.Size(239, 31);
            this.bttnCalcular.TabIndex = 0;
            this.bttnCalcular.Text = "Sequência Fibonacci ( N primeiros )";
            this.bttnCalcular.UseVisualStyleBackColor = false;
            this.bttnCalcular.Click += new System.EventHandler(this.bttnCalcular_Click);
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.Location = new System.Drawing.Point(51, 109);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.Size = new System.Drawing.Size(239, 244);
            this.richTxtBxTela.TabIndex = 1;
            this.richTxtBxTela.Text = "";
            this.richTxtBxTela.TextChanged += new System.EventHandler(this.richTxtBxTela_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "N primeiros da sequência :";
            // 
            // numericUDN
            // 
            this.numericUDN.Location = new System.Drawing.Point(221, 18);
            this.numericUDN.Name = "numericUDN";
            this.numericUDN.Size = new System.Drawing.Size(120, 26);
            this.numericUDN.TabIndex = 3;
            this.numericUDN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUDN.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // Ex6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(353, 365);
            this.Controls.Add(this.numericUDN);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.bttnCalcular);
            this.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Ex6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex6";
            ((System.ComponentModel.ISupportInitialize)(this.numericUDN)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttnCalcular;
        private System.Windows.Forms.RichTextBox richTxtBxTela;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUDN;
    }
}