﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex7 : Form
    {
        public Ex7()
        {
            InitializeComponent();
        }

        private void bttnVerificar_Click(object sender, EventArgs e)
        {
            richTxtBxTela.Clear();
            int IntervaloDe, IntervaloAte, N;

            IntervaloDe = (int)numericUDInterloDE.Value;
            IntervaloAte = (int)numericUDIntervaloATE.Value;

            for (int i = IntervaloDe; i <= IntervaloAte; i++)
            {
                N = i % 9;

                if (N == 0)
                {
                    richTxtBxTela.AppendText("--> " + i);
                    richTxtBxTela.AppendText(Environment.NewLine);
                    richTxtBxTela.ScrollToCaret();
                }
            }
            
        }
    }
}
