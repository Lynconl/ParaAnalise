﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex3 : Form
    {
        public Ex3()
        {
            InitializeComponent();
        }

        private void bttnCalcular_Click(object sender, EventArgs e)
        {
            int Expoente, Resultado = 1; double Base;

            Expoente = Convert.ToInt32(maskedTxtBxExpoente.Text);
            Base = Convert.ToDouble(maskedTxtBxBase.Text);

            for (int x = 1; x <= Expoente; x++)
            {                      
               Resultado *= Convert.ToInt32(Base);               
            }       
            richTxtBxTela.AppendText("Resultado: " + Resultado);
            richTxtBxTela.AppendText(Environment.NewLine);

        }
    }
}
