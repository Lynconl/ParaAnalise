﻿namespace ListadeLoops
{
    partial class Ex8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDe = new System.Windows.Forms.Label();
            this.numericUDDE = new System.Windows.Forms.NumericUpDown();
            this.bttnVerificar = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.lblAte = new System.Windows.Forms.Label();
            this.lblDividir = new System.Windows.Forms.Label();
            this.numericUDAte = new System.Windows.Forms.NumericUpDown();
            this.numericUDDividir = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDDE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDAte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDDividir)).BeginInit();
            this.SuspendLayout();
            // 
            // lblDe
            // 
            this.lblDe.AutoSize = true;
            this.lblDe.Location = new System.Drawing.Point(12, 10);
            this.lblDe.Name = "lblDe";
            this.lblDe.Size = new System.Drawing.Size(88, 18);
            this.lblDe.TabIndex = 0;
            this.lblDe.Text = "Intervalo De:";
            // 
            // numericUDDE
            // 
            this.numericUDDE.Location = new System.Drawing.Point(147, 8);
            this.numericUDDE.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numericUDDE.Minimum = new decimal(new int[] {
            99999,
            0,
            0,
            -2147483648});
            this.numericUDDE.Name = "numericUDDE";
            this.numericUDDE.Size = new System.Drawing.Size(120, 26);
            this.numericUDDE.TabIndex = 1;
            this.numericUDDE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDDE.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // bttnVerificar
            // 
            this.bttnVerificar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnVerificar.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnVerificar.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.bttnVerificar.Location = new System.Drawing.Point(286, 8);
            this.bttnVerificar.Name = "bttnVerificar";
            this.bttnVerificar.Size = new System.Drawing.Size(75, 93);
            this.bttnVerificar.TabIndex = 2;
            this.bttnVerificar.Text = "Verificar";
            this.bttnVerificar.UseVisualStyleBackColor = false;
            this.bttnVerificar.Click += new System.EventHandler(this.bttnVerificar_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(16, 112);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(345, 211);
            this.richTextBox1.TabIndex = 3;
            this.richTextBox1.Text = "";
            this.richTextBox1.Visible = false;
            // 
            // lblAte
            // 
            this.lblAte.AutoSize = true;
            this.lblAte.Location = new System.Drawing.Point(12, 46);
            this.lblAte.Name = "lblAte";
            this.lblAte.Size = new System.Drawing.Size(93, 18);
            this.lblAte.TabIndex = 4;
            this.lblAte.Text = "Intervalo Até:";
            // 
            // lblDividir
            // 
            this.lblDividir.AutoSize = true;
            this.lblDividir.Location = new System.Drawing.Point(13, 82);
            this.lblDividir.Name = "lblDividir";
            this.lblDividir.Size = new System.Drawing.Size(86, 18);
            this.lblDividir.TabIndex = 5;
            this.lblDividir.Text = "Divisível por:";
            // 
            // numericUDAte
            // 
            this.numericUDAte.Location = new System.Drawing.Point(147, 44);
            this.numericUDAte.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numericUDAte.Minimum = new decimal(new int[] {
            99999,
            0,
            0,
            -2147483648});
            this.numericUDAte.Name = "numericUDAte";
            this.numericUDAte.Size = new System.Drawing.Size(120, 26);
            this.numericUDAte.TabIndex = 6;
            this.numericUDAte.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDAte.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            this.numericUDAte.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // numericUDDividir
            // 
            this.numericUDDividir.Location = new System.Drawing.Point(147, 80);
            this.numericUDDividir.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numericUDDividir.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUDDividir.Name = "numericUDDividir";
            this.numericUDDividir.Size = new System.Drawing.Size(120, 26);
            this.numericUDDividir.TabIndex = 7;
            this.numericUDDividir.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDDividir.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            this.numericUDDividir.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // Ex8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(376, 330);
            this.Controls.Add(this.numericUDDividir);
            this.Controls.Add(this.numericUDAte);
            this.Controls.Add(this.lblDividir);
            this.Controls.Add(this.lblAte);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.bttnVerificar);
            this.Controls.Add(this.numericUDDE);
            this.Controls.Add(this.lblDe);
            this.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Ex8";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex8";
            ((System.ComponentModel.ISupportInitialize)(this.numericUDDE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDAte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDDividir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDe;
        private System.Windows.Forms.NumericUpDown numericUDDE;
        private System.Windows.Forms.Button bttnVerificar;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label lblAte;
        private System.Windows.Forms.Label lblDividir;
        private System.Windows.Forms.NumericUpDown numericUDAte;
        private System.Windows.Forms.NumericUpDown numericUDDividir;
    }
}