﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex15 : Form
    {
        public Ex15()
        {
            InitializeComponent();
        }

        private void bttnMostrar_Click(object sender, EventArgs e)
        {
            int N;

            N = (int)numericUDNL.Value;
            

            for (int i = 1; i <= N; i++)
            {
                richTxtBxTela.AppendText(Environment.NewLine);

                for (int x = 1; x <= i; x++)
                {
                    richTxtBxTela.AppendText(x.ToString());
                }
            }
        }

        private void numericUDNL_ValueChanged(object sender, EventArgs e)
        {

        }

        private void lblNLinhas_Click(object sender, EventArgs e)
        {

        }

        private void richTxtBxTela_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
