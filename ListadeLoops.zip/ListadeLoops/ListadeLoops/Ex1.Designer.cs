﻿namespace ListadeLoops
{
    partial class Ex1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttnExibir = new System.Windows.Forms.Button();
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // bttnExibir
            // 
            this.bttnExibir.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnExibir.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnExibir.Location = new System.Drawing.Point(40, 12);
            this.bttnExibir.Name = "bttnExibir";
            this.bttnExibir.Size = new System.Drawing.Size(98, 30);
            this.bttnExibir.TabIndex = 1;
            this.bttnExibir.Text = "Exibir";
            this.bttnExibir.UseVisualStyleBackColor = false;
            this.bttnExibir.Click += new System.EventHandler(this.bttnExibir_Click);
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTxtBxTela.ForeColor = System.Drawing.Color.DarkGreen;
            this.richTxtBxTela.Location = new System.Drawing.Point(12, 48);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.Size = new System.Drawing.Size(157, 206);
            this.richTxtBxTela.TabIndex = 2;
            this.richTxtBxTela.Text = "";
            // 
            // Ex1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(179, 266);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.bttnExibir);
            this.MaximizeBox = false;
            this.Name = "Ex1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bttnExibir;
        private System.Windows.Forms.RichTextBox richTxtBxTela;
    }
}