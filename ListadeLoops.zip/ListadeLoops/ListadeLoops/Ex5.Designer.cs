﻿namespace ListadeLoops
{
    partial class Ex5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblValor = new System.Windows.Forms.Label();
            this.numericUDValor = new System.Windows.Forms.NumericUpDown();
            this.bttnVerificar = new System.Windows.Forms.Button();
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDValor)).BeginInit();
            this.SuspendLayout();
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Location = new System.Drawing.Point(12, 14);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(105, 18);
            this.lblValor.TabIndex = 0;
            this.lblValor.Text = "Insira um Valor:";
            // 
            // numericUDValor
            // 
            this.numericUDValor.Location = new System.Drawing.Point(139, 12);
            this.numericUDValor.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numericUDValor.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUDValor.Name = "numericUDValor";
            this.numericUDValor.Size = new System.Drawing.Size(120, 26);
            this.numericUDValor.TabIndex = 1;
            this.numericUDValor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDValor.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            this.numericUDValor.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // bttnVerificar
            // 
            this.bttnVerificar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnVerificar.Location = new System.Drawing.Point(294, 12);
            this.bttnVerificar.Name = "bttnVerificar";
            this.bttnVerificar.Size = new System.Drawing.Size(75, 26);
            this.bttnVerificar.TabIndex = 2;
            this.bttnVerificar.Text = "Verificar";
            this.bttnVerificar.UseVisualStyleBackColor = false;
            this.bttnVerificar.Click += new System.EventHandler(this.bttnVerificar_Click);
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.Location = new System.Drawing.Point(12, 44);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.Size = new System.Drawing.Size(357, 268);
            this.richTxtBxTela.TabIndex = 3;
            this.richTxtBxTela.Text = "";
            this.richTxtBxTela.Visible = false;
            // 
            // Ex5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CadetBlue;
            this.ClientSize = new System.Drawing.Size(381, 324);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.bttnVerificar);
            this.Controls.Add(this.numericUDValor);
            this.Controls.Add(this.lblValor);
            this.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "Ex5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex5";
            ((System.ComponentModel.ISupportInitialize)(this.numericUDValor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.NumericUpDown numericUDValor;
        private System.Windows.Forms.Button bttnVerificar;
        private System.Windows.Forms.RichTextBox richTxtBxTela;
    }
}