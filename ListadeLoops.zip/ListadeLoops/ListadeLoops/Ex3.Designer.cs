﻿namespace ListadeLoops
{
    partial class Ex3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBase = new System.Windows.Forms.Label();
            this.bttnCalcular = new System.Windows.Forms.Button();
            this.maskedTxtBxBase = new System.Windows.Forms.MaskedTextBox();
            this.maskedTxtBxExpoente = new System.Windows.Forms.MaskedTextBox();
            this.lblExpoente = new System.Windows.Forms.Label();
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // lblBase
            // 
            this.lblBase.AutoSize = true;
            this.lblBase.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBase.Location = new System.Drawing.Point(16, 19);
            this.lblBase.Name = "lblBase";
            this.lblBase.Size = new System.Drawing.Size(48, 23);
            this.lblBase.TabIndex = 0;
            this.lblBase.Text = "Base:";
            // 
            // bttnCalcular
            // 
            this.bttnCalcular.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnCalcular.Location = new System.Drawing.Point(167, 120);
            this.bttnCalcular.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bttnCalcular.Name = "bttnCalcular";
            this.bttnCalcular.Size = new System.Drawing.Size(99, 32);
            this.bttnCalcular.TabIndex = 3;
            this.bttnCalcular.Text = "Calcular";
            this.bttnCalcular.UseVisualStyleBackColor = false;
            this.bttnCalcular.Click += new System.EventHandler(this.bttnCalcular_Click);
            // 
            // maskedTxtBxBase
            // 
            this.maskedTxtBxBase.Location = new System.Drawing.Point(153, 20);
            this.maskedTxtBxBase.Name = "maskedTxtBxBase";
            this.maskedTxtBxBase.Size = new System.Drawing.Size(128, 26);
            this.maskedTxtBxBase.TabIndex = 4;
            this.maskedTxtBxBase.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTxtBxExpoente
            // 
            this.maskedTxtBxExpoente.Location = new System.Drawing.Point(153, 71);
            this.maskedTxtBxExpoente.Mask = "00";
            this.maskedTxtBxExpoente.Name = "maskedTxtBxExpoente";
            this.maskedTxtBxExpoente.Size = new System.Drawing.Size(128, 26);
            this.maskedTxtBxExpoente.TabIndex = 5;
            this.maskedTxtBxExpoente.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.maskedTxtBxExpoente.ValidatingType = typeof(int);
            // 
            // lblExpoente
            // 
            this.lblExpoente.AutoSize = true;
            this.lblExpoente.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpoente.Location = new System.Drawing.Point(16, 70);
            this.lblExpoente.Name = "lblExpoente";
            this.lblExpoente.Size = new System.Drawing.Size(82, 23);
            this.lblExpoente.TabIndex = 6;
            this.lblExpoente.Text = "Expoente:";
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.Location = new System.Drawing.Point(20, 170);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.Size = new System.Drawing.Size(261, 173);
            this.richTxtBxTela.TabIndex = 7;
            this.richTxtBxTela.Text = "";
            // 
            // Ex3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(301, 365);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.lblExpoente);
            this.Controls.Add(this.maskedTxtBxExpoente);
            this.Controls.Add(this.maskedTxtBxBase);
            this.Controls.Add(this.bttnCalcular);
            this.Controls.Add(this.lblBase);
            this.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Ex3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBase;
        private System.Windows.Forms.Button bttnCalcular;
        private System.Windows.Forms.MaskedTextBox maskedTxtBxBase;
        private System.Windows.Forms.MaskedTextBox maskedTxtBxExpoente;
        private System.Windows.Forms.Label lblExpoente;
        private System.Windows.Forms.RichTextBox richTxtBxTela;
    }
}