﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex12 : Form
    {
        public Ex12()
        {
            InitializeComponent();
        }

        private void bttnCalcular_Click(object sender, EventArgs e)
        {
            double n, N, Calc1, Calc2=0, X;

            n = (int)numericUDValordeN.Value;
            N = (int)numericUDValordeN2.Value;

            Calc1 = N / (n + 1);
            
            for (double i = 0; i <= n; i++)
            {
                Calc2 += Calc1;
                X = Calc2 - Calc1;

                richTxtBxTela.AppendText("Resultado de: " + N + " / " + (n+1) + " = " + Calc1.ToString("N3") + " + " + X.ToString("N3") + " = " + Calc2.ToString("N3"));
                richTxtBxTela.AppendText(Environment.NewLine);
            }
        }
    }
}
