﻿namespace ListadeLoops
{
    partial class Ex14
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNLinhas = new System.Windows.Forms.Label();
            this.numericUDNL = new System.Windows.Forms.NumericUpDown();
            this.bttnMostrar = new System.Windows.Forms.Button();
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDNL)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNLinhas
            // 
            this.lblNLinhas.AutoSize = true;
            this.lblNLinhas.Location = new System.Drawing.Point(12, 15);
            this.lblNLinhas.Name = "lblNLinhas";
            this.lblNLinhas.Size = new System.Drawing.Size(124, 18);
            this.lblNLinhas.TabIndex = 0;
            this.lblNLinhas.Text = "Informe N(Linhas):";
            // 
            // numericUDNL
            // 
            this.numericUDNL.Location = new System.Drawing.Point(161, 13);
            this.numericUDNL.Name = "numericUDNL";
            this.numericUDNL.Size = new System.Drawing.Size(120, 26);
            this.numericUDNL.TabIndex = 1;
            this.numericUDNL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDNL.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // bttnMostrar
            // 
            this.bttnMostrar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnMostrar.Location = new System.Drawing.Point(298, 6);
            this.bttnMostrar.Name = "bttnMostrar";
            this.bttnMostrar.Size = new System.Drawing.Size(83, 41);
            this.bttnMostrar.TabIndex = 2;
            this.bttnMostrar.Text = "Mostrar";
            this.bttnMostrar.UseVisualStyleBackColor = false;
            this.bttnMostrar.Click += new System.EventHandler(this.bttnMostrar_Click);
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.Location = new System.Drawing.Point(12, 53);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.Size = new System.Drawing.Size(369, 295);
            this.richTxtBxTela.TabIndex = 3;
            this.richTxtBxTela.Text = "";
            // 
            // Ex14
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(393, 361);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.bttnMostrar);
            this.Controls.Add(this.numericUDNL);
            this.Controls.Add(this.lblNLinhas);
            this.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "Ex14";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex14";
            ((System.ComponentModel.ISupportInitialize)(this.numericUDNL)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNLinhas;
        private System.Windows.Forms.NumericUpDown numericUDNL;
        private System.Windows.Forms.Button bttnMostrar;
        private System.Windows.Forms.RichTextBox richTxtBxTela;
    }
}