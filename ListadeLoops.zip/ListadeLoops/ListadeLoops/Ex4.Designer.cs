﻿namespace ListadeLoops
{
    partial class Ex4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.numericUDValor = new System.Windows.Forms.NumericUpDown();
            this.bttnExibir = new System.Windows.Forms.Button();
            this.richTxtBxTela = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDValor)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Informe um Valor:";
            // 
            // numericUDValor
            // 
            this.numericUDValor.Location = new System.Drawing.Point(147, 16);
            this.numericUDValor.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUDValor.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.numericUDValor.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUDValor.Name = "numericUDValor";
            this.numericUDValor.Size = new System.Drawing.Size(124, 26);
            this.numericUDValor.TabIndex = 1;
            this.numericUDValor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDValor.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            this.numericUDValor.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // bttnExibir
            // 
            this.bttnExibir.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnExibir.Location = new System.Drawing.Point(286, 16);
            this.bttnExibir.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bttnExibir.Name = "bttnExibir";
            this.bttnExibir.Size = new System.Drawing.Size(73, 26);
            this.bttnExibir.TabIndex = 2;
            this.bttnExibir.Text = "Verificar";
            this.bttnExibir.UseVisualStyleBackColor = false;
            this.bttnExibir.Click += new System.EventHandler(this.bttnExibir_Click);
            // 
            // richTxtBxTela
            // 
            this.richTxtBxTela.Location = new System.Drawing.Point(15, 53);
            this.richTxtBxTela.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.richTxtBxTela.Name = "richTxtBxTela";
            this.richTxtBxTela.Size = new System.Drawing.Size(344, 280);
            this.richTxtBxTela.TabIndex = 3;
            this.richTxtBxTela.Text = "";
            this.richTxtBxTela.Visible = false;
            // 
            // Ex4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(372, 347);
            this.Controls.Add(this.richTxtBxTela);
            this.Controls.Add(this.bttnExibir);
            this.Controls.Add(this.numericUDValor);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Ex4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex4";
            ((System.ComponentModel.ISupportInitialize)(this.numericUDValor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUDValor;
        private System.Windows.Forms.Button bttnExibir;
        private System.Windows.Forms.RichTextBox richTxtBxTela;
    }
}