﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex2 : Form
    {
        public Ex2()
        {
            InitializeComponent();
        }

        private void bttnHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ao clilcar em (Calcular) irá somar os 10 primeiros números naturais!", "Ajuda", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void bttnCalcular_Click(object sender, EventArgs e)
        {
            int Valor = 0;
            for (int x = 0; x <= 10; x++)
            {
                Valor += x;
                
                richTxtBxTela.AppendText("Resultado de: " + (Valor-x) + " + " + x + "  é:  " + Valor);
                richTxtBxTela.AppendText(Environment.NewLine);
            }
        }
    }
}
