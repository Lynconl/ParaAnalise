﻿namespace ListadeLoops
{
    partial class Ex10
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInforme = new System.Windows.Forms.Label();
            this.numericUDValorInformado = new System.Windows.Forms.NumericUpDown();
            this.bttnVerificar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUDValorInformado)).BeginInit();
            this.SuspendLayout();
            // 
            // lblInforme
            // 
            this.lblInforme.AutoSize = true;
            this.lblInforme.Location = new System.Drawing.Point(12, 14);
            this.lblInforme.Name = "lblInforme";
            this.lblInforme.Size = new System.Drawing.Size(91, 18);
            this.lblInforme.TabIndex = 0;
            this.lblInforme.Text = "Informe 1 N°:";
            // 
            // numericUDValorInformado
            // 
            this.numericUDValorInformado.Location = new System.Drawing.Point(137, 12);
            this.numericUDValorInformado.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.numericUDValorInformado.Name = "numericUDValorInformado";
            this.numericUDValorInformado.Size = new System.Drawing.Size(120, 26);
            this.numericUDValorInformado.TabIndex = 1;
            this.numericUDValorInformado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUDValorInformado.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // bttnVerificar
            // 
            this.bttnVerificar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnVerificar.ForeColor = System.Drawing.Color.Green;
            this.bttnVerificar.Location = new System.Drawing.Point(28, 50);
            this.bttnVerificar.Name = "bttnVerificar";
            this.bttnVerificar.Size = new System.Drawing.Size(200, 33);
            this.bttnVerificar.TabIndex = 2;
            this.bttnVerificar.Text = "Verificar se é primo!";
            this.bttnVerificar.UseVisualStyleBackColor = false;
            this.bttnVerificar.Click += new System.EventHandler(this.bttnVerificar_Click);
            // 
            // Ex10
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(269, 95);
            this.Controls.Add(this.bttnVerificar);
            this.Controls.Add(this.numericUDValorInformado);
            this.Controls.Add(this.lblInforme);
            this.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "Ex10";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ex10";
            ((System.ComponentModel.ISupportInitialize)(this.numericUDValorInformado)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInforme;
        private System.Windows.Forms.NumericUpDown numericUDValorInformado;
        private System.Windows.Forms.Button bttnVerificar;
    }
}