﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex4 : Form
    {
        public Ex4()
        {
            InitializeComponent();
        }

        private void bttnExibir_Click(object sender, EventArgs e)
        {
            richTxtBxTela.Visible = true;
            richTxtBxTela.Clear();

            int Pares, Verifica;

            Pares = (int)numericUDValor.Value;

            for (int x = 0; x <= Pares; x++)
            {
                Verifica = x % 2;

                if (Verifica == 0)
                {
                    richTxtBxTela.AppendText("-->  " + x);
                    richTxtBxTela.AppendText(Environment.NewLine);
                }
            }
            numericUDValor.Value = 1;
            numericUDValor.Focus();

        }
    }
}
