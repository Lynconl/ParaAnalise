﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListadeLoops
{
    public partial class Ex6 : Form
    {
        public Ex6()
        {
            InitializeComponent();
        }

        private void bttnCalcular_Click(object sender, EventArgs e)
        {
            int N, Fib0 = 0, Fib1 = 1, Fibn; // Variáveis.

            N = (int)numericUDN.Value; // Guarda o Valor informado em N;

            if (N > 0) // Se N for maior que 0.
            {
                N -= 3; // N - 3
                richTxtBxTela.AppendText("Sequência é: " + Fib0); // 0
                richTxtBxTela.AppendText(Environment.NewLine); // Pula Linha
                richTxtBxTela.AppendText("Sequência é: " + Fib1); // 1
                richTxtBxTela.AppendText(Environment.NewLine); // Pula Linha            
                
                for (int i = 0; i <= N; i++) // Loop começa em 0 e termina em N.
                {
                    Fibn = Fib0 + Fib1; // Faz o calculo do Antec + Sucessor.
                    Fib0 = Fib1; // Coloca o novo valor do Antecessor.
                    Fib1 = Fibn; // Coloca o novo valor para o Sucessor.
                    richTxtBxTela.AppendText("Sequência é " + Fibn); // Mostra na Tela;
                    richTxtBxTela.AppendText(Environment.NewLine); // Pula Linha.
                    richTxtBxTela.ScrollToCaret(); // Rola a Tela Automaticamente.
                }
            }
        }

        private void richTxtBxTela_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
